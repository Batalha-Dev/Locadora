# 03 — Algoritmos: Ordenação e Busca

Os algoritmos ficam em `estruturas/ordenacao.h`, dentro do namespace `Ordenacao`.
São **genéricos**: funcionam com qualquer tipo e qualquer critério, graças a
**comparadores** (lambdas) passados por parâmetro.

---

## 3.1 Merge Sort (ordenação)

### O que é
Algoritmo de ordenação por **divisão e conquista**:
1. **Divide** o vetor ao meio, repetidamente, até sobrarem pedaços de tamanho 1.
2. **Conquista (intercala):** junta os pedaços em ordem, de baixo para cima.

```
[5, 2, 8, 1]
   ├── [5, 2] ── [5] [2] → intercala → [2, 5]
   └── [8, 1] ── [8] [1] → intercala → [1, 8]
                          → intercala → [1, 2, 5, 8]
```

### Por que escolhemos Merge Sort
- **Complexidade O(n log n)** no melhor, médio E pior caso (previsível).
- É **estável**: elementos iguais mantêm a ordem original. Isso importa em ordenações
  compostas (ex.: ordenar por data e, em empate, por valor).

### Como funciona (trecho comentado)
```cpp
template <typename T, typename Comp>
void mergeSort(VetorDinamico<T>& v, int esq, int dir, Comp comp) {
    if (esq >= dir) return;                 // pedaço de 0 ou 1 elemento já está ordenado
    int meio = esq + (dir - esq) / 2;       // evita overflow de (esq+dir)
    mergeSort(v, esq, meio, comp);          // ordena a metade da esquerda
    mergeSort(v, meio + 1, dir, comp);      // ordena a metade da direita
    merge(v, esq, meio, dir, comp);         // intercala as duas metades ordenadas
}
```

O `merge` copia as duas metades para arrays temporários `L` e `R` (na heap, para não
estourar a pilha de recursão) e vai escolhendo o menor da frente de cada um:

```cpp
while (i < n1 && j < n2) {
    if (comp(L[i], R[j])) v[k++] = L[i++];  // comp decide quem vem antes
    else                   v[k++] = R[j++];
}
```

### Como usar
```cpp
// Ordena locações por data (mais antiga primeiro)
Ordenacao::ordenar(vetor, [](const Locacao& a, const Locacao& b) {
    return a.dataInicio < b.dataInicio;     // "a vem antes de b"
});
```

> 👶 **O comparador manda.** Trocar `<` por `>` inverte a ordem. O algoritmo é o mesmo;
> só o critério muda.

> ⚙️ **Como modificar o critério:** basta passar outra lambda. Para ordenar por valor
> decrescente: `return a.valorTotal > b.valorTotal;`.

---

## 3.2 Busca Binária

### O que é
Encontra um elemento num vetor **já ordenado** olhando sempre o **meio** e descartando
metade a cada passo.

```
Procurando 23 em [4, 8, 15, 16, 23, 42]:
  meio = 15  → 23 > 15, descarta a esquerda
  meio = 23  → achou!  (2 passos em vez de 5)
```

### Por que é tão melhor que a busca linear
| n (itens) | Busca linear (O(n)) | Busca binária (O(log n)) |
|-----------|--------------------:|-------------------------:|
| 1.000     | até 1.000 passos    | ~10 passos               |
| 1.000.000 | até 1.000.000       | ~20 passos               |

### Pré-condição CRÍTICA
O vetor **precisa estar ordenado** pela mesma chave que você procura. Se não estiver, o
resultado é indefinido. Por isso `consultas.h` **ordena antes de buscar**:

```cpp
inline int buscarLocacaoPorId(VetorDinamico<Locacao>& vetor, int idAlvo) {
    Ordenacao::ordenar(vetor, [](const Locacao& a, const Locacao& b){ return a.id < b.id; });
    return Ordenacao::buscaBinaria(vetor, idAlvo, [](const Locacao& l){ return l.id; });
}
```

### Como funciona (trecho comentado)
```cpp
template <typename T, typename Chave, typename Extrator>
int buscaBinaria(VetorDinamico<T>& v, const Chave& alvo, Extrator extrair) {
    int esq = 0, dir = v.getTamanho() - 1;
    while (esq <= dir) {
        int meio = esq + (dir - esq) / 2;
        Chave chaveMeio = extrair(v[meio]);   // 'extrair' pega a chave do elemento
        if (chaveMeio == alvo) return meio;    // achou → devolve o índice
        if (chaveMeio < alvo)  esq = meio + 1; // alvo está à direita
        else                   dir = meio - 1; // alvo está à esquerda
    }
    return -1;                                 // não encontrado
}
```

O parâmetro `extrair` é uma lambda que diz "qual campo é a chave". Para locação por ID:
`[](const Locacao& l){ return l.id; }`.

> 🧑‍💻 **Onde aparece na UI:** menu **Consultas → Busca binária de locação por ID**. A
> tela mostra um dashboard com os IDs existentes e demonstra o algoritmo encontrando a
> posição no vetor ordenado.

---

## 3.3 Por que não QuickSort?

QuickSort tem caso médio O(n log n), mas **pior caso O(n²)** e **não é estável**. Para um
sistema que precisa de ordenações compostas e comportamento previsível, o Merge Sort é a
escolha mais segura. (O custo é usar memória extra O(n) nos arrays temporários.)

Continue em → [04 — Modelos de Dados](04-modelos-de-dados.md)
