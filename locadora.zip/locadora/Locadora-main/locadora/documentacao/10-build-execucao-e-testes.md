# 10 — Build, Execução e Testes

## 10.1 Pré-requisitos

- Um compilador C++ com suporte a **C++17** (g++ 7+, clang 6+, MSVC 2017+).
- Opcional: **CMake 3.20+** (ou usar o `Makefile`, ou chamar o `g++` direto).

> 🧑‍💻 **Por que o build é simples?** Quase tudo está em arquivos `.h` incluídos pelo
> `main.cpp`. Então compilar o `main.cpp` já compila o sistema inteiro.

---

## 10.2 Compilar e rodar — 3 formas

### Forma 1 — g++ direto (mais simples)
```bash
cd locadora
g++ -std=c++17 -O2 -o locadora main.cpp
./locadora
```

### Forma 2 — Makefile
```bash
cd locadora
make            # gera o executável 'locadora'
make run        # compila e executa
make test       # compila e roda os testes
make clean      # remove os binários
```

### Forma 3 — CMake (usada pelo CLion)
```bash
cd locadora
cmake -S . -B build
cmake --build build
./build/locadora
```
O `CMakeLists.txt` define dois alvos: `locadora` (o sistema) e `testes_locadora` (os
testes), este último integrado ao **CTest**.

---

## 10.3 Rodar os testes

```bash
# via g++
g++ -std=c++17 -O2 -o testes_locadora testes/testes.cpp && ./testes_locadora

# via make
make test

# via CTest (depois do cmake build)
cd build && ctest --output-on-failure
```

O executável de testes **retorna 0 se tudo passou** e 1 caso contrário — ideal para
integração contínua (CI).

### O que os testes cobrem (`testes/testes.cpp`)
- Cadastro e **unicidade** via hash (placa e CPF não podem repetir).
- Ciclo **locação → devolução** com transições de status corretas.
- Regra de cobrança mínima de **1 diária**.
- Consistência da disponibilidade da frota.

Cada verificação usa uma macro `CHECK(condição)` que reporta OK/FALHA.

> ⚙️ **Como adicionar um teste:** abra `testes/testes.cpp`, crie um cenário (instancie os
> gerenciadores, execute operações) e use `CHECK(...)` para comparar o resultado obtido
> com o esperado.

---

## 10.4 Onde ficam os dados gerados

Ao rodar, o programa cria (no diretório atual de execução):
- `dados/` — os CSVs (carros, clientes, locações, marcas, modelos, categorias);
- `juridico/` — os PDFs (contratos e aditivos).

Para "zerar" o sistema, apague essas pastas — ele volta a carregar a demonstração.

---

## 10.5 Dicas de terminal

- O visual usa **cores ANSI de 256 níveis** e **caracteres Unicode**. Funciona no
  Terminal do macOS, iTerm, Windows Terminal e na maioria dos terminais Linux.
- Se aparecerem códigos estranhos em vez de cores, seu terminal pode não suportar ANSI
  (raro hoje em dia).
- Para nomes muito longos nas tabelas, **alargue a janela** do terminal (a tabela não
  corta o conteúdo; quem quebra a linha é o terminal).

Continue em → [11 — Como Modificar (receitas)](11-receitas-como-modificar.md)
