# 05 — Serviços (Lógica de Negócio)

A camada `servicos/` é o **cérebro** do sistema. Ela aplica regras, mantém a consistência
e coordena as estruturas de dados. As telas (`ui/`) nunca mexem direto nas estruturas:
elas pedem para os serviços.

---

## 5.1 `GerenciadorFrota` — `gerenciador_frota.h`

Guarda os veículos e as categorias, e mantém **três índices em paralelo**:

```cpp
ListaEncadeada<Carro>                    frota;        // armazenamento principal
ListaEstatica<Categoria, MAX_CATEGORIAS> categorias;   // 6 categorias fixas
Fila<int>                                filaEspera[MAX_CATEGORIAS]; // fila por categoria
HashTable<std::string, int>              hashPorPlaca; // placa → id  (busca O(1))
HashTable<int, int>                      hashPorId;    // id → id     (existência O(1))
GeradorId                                geradorId;    // ids automáticos
```

> 🧑‍💻 **Por que lista + 2 hashes?** A lista é a "fonte da verdade". As hashes são
> **índices** para achar rápido por placa ou ID. É o mesmo princípio de um índice de
> livro: o conteúdo está nas páginas (lista), o índice (hash) só diz em que página está.

### Operações-chave (comentadas)
```cpp
Carro* cadastrar(marca, modelo, placa, ano, categoriaId) {
    if (!buscarCategoria(categoriaId)) return nullptr;  // categoria precisa existir
    if (hashPorPlaca.buscar(placa))    return nullptr;  // placa não pode repetir
    double diaria = buscarCategoria(categoriaId)->diariaPadrao;  // herda a diária
    int id = geradorId.obter();                          // ID automático
    frota.inserirFim({id, marca, modelo, placa, ano, categoriaId, diaria});
    hashPorPlaca.inserir(placa, id);                     // indexa por placa
    hashPorId.inserir(id, id);                           // indexa por id
    return /* ponteiro para o carro recém-criado */;
}
```

- `buscarPorId` / `buscarPorPlaca` — usam a hash → **O(1)** médio.
- `marcarLocado` / `marcarDisponivel` / `marcarManutencao` — mudam o status (a tela de
  manutenção só oferece a ação coerente com o status atual).
- **Categorias:** `adicionarCategoria(nome, descricao, diaria)`, `removerCategoria(id)`,
  `proximoIdCategoriaLivre()` (acha o menor ID livre, permitindo reuso após remoção),
  `contarVeiculosNaCategoria(id)` (usado para impedir remover categoria em uso).
- **Fila de espera:** `entrarFilaEspera`, `proximoDaFila` (FIFO por categoria).

> ⚙️ **Mais categorias?** Aumente `MAX_CATEGORIAS` (dimensiona a lista estática e o array
> de filas).

---

## 5.2 `GerenciadorClientes` — `gerenciador_clientes.h`

Mesmo padrão: lista de clientes + hash por CPF + hash por ID.

```cpp
Cliente* cadastrar(nome, cpf, telefone, email) {
    if (hashPorCpf.buscar(cpf)) return nullptr;  // CPF duplicado → recusa
    int id = geradorId.obter();
    clientes.inserirFim({id, nome, cpf, telefone, email});
    hashPorCpf.inserir(cpf, id);
    hashPorId.inserir(id, id);
    return /* ponteiro para o novo cliente */;
}
```

- `buscarPorId`, `buscarPorCpf` — **O(1)** médio via hash.
- `remover(id, reutilizarId)` — remove da lista e das duas hashes; o `reutilizarId`
  controla se o ID volta para a pilha de reuso (não reaproveita se houver histórico que
  ainda aponta para ele, preservando integridade).

---

## 5.3 `GerenciadorLocacoes` — `gerenciador_locacoes.h` (o mais rico)

Coordena frota + clientes (recebe **referências** a eles), mantém a lista de locações e
a **pilha de histórico** para o desfazer.

```cpp
ListaEncadeada<Locacao> locacoes;
Pilha<Operacao>         historicoOps;  // para o "desfazer"
GerenciadorFrota&       frota;
GerenciadorClientes&    clientes;
GeradorId               geradorId;
```

### Consistência (a regra que evita bagunça)
```cpp
bool clienteTemLocacaoAtiva(int idCliente);  // 1 locação ativa por cliente
```

### Registrar locação
```cpp
Locacao* registrarLocacao(idCliente, idCarro, dias) {
    if (!cli || !car)                            return nullptr;
    if (car->status != StatusCarro::DISPONIVEL)  return nullptr; // carro precisa estar livre
    if (dias <= 0)                               return nullptr;
    if (clienteTemLocacaoAtiva(idCliente))       return nullptr; // consistência
    // cria a locação, marca o carro como LOCADO e empilha a operação (undo)
}
```

### Devolução (recálculo pelo tempo real)
```cpp
bool registrarDevolucao(idLocacao) {
    loc->dataFimReal = agora;
    loc->status = StatusLocacao::CONCLUIDA;
    loc->valorTotal = loc->valorCobrado(car->diaria, agora); // cobra pelos dias reais
    frota.marcarDisponivel(loc->idCarro);                    // carro volta a circular
    frota.proximoDaFila(car->categoriaId);                   // chama quem espera
}
```

### Renovação
```cpp
bool renovarLocacao(idLocacao, diasAdicionais) {
    loc->dataFimPrevista += diasAdicionais * 86400;      // estende o prazo
    loc->valorTotal      += diasAdicionais * car->diaria; // soma as diárias
}
```

### Devolução em atraso com multa
```cpp
const double FATOR_MULTA_DIA = 0.30;  // 30% da diária por dia de atraso

FechamentoAtraso calcularAtraso(idLocacao);          // calcula SEM efetivar (prévia)
FechamentoAtraso registrarDevolucaoComMulta(idLocacao); // efetiva e grava a multa
```

`FechamentoAtraso` é um pacotinho com `{ diasAtraso, valorDiarias, multa, total }` —
usado pela tela para mostrar a prévia e confirmar.

### Desfazer (undo)
```cpp
std::string desfazerUltima() {
    Operacao op = historicoOps.desempilhar();   // pega a última ação
    switch (op.tipo) {
        case REGISTRAR_LOCACAO:   /* cancela a locação, libera o carro */ break;
        case REGISTRAR_DEVOLUCAO: /* reabre a locação, marca carro locado */ break;
        ...
    }
}
```

### Financeiro
```cpp
double receitaTotal();      // soma valorTotal das CONCLUÍDAS
double receitaMultas();     // soma as multas das CONCLUÍDAS
double receitaPrevista();   // soma valorTotal das ATIVAS
int    locacoesAtivas();
```

### Reconciliação (consistência ao carregar)
```cpp
int reconciliarFrota();
```
Após carregar os arquivos, garante que o **status do carro bate com as locações ativas**:
- carro com locação ativa deve estar `LOCADO`;
- carro `LOCADO` sem locação ativa volta a `DISPONIVEL`.
Corrige divergências automaticamente e retorna quantas corrigiu.

> 👶 **Por que isso é importante?** Se alguém editar o CSV na mão (ou houver um
> encerramento abrupto), a frota e as locações podem "discordar". A reconciliação
> conserta isso na inicialização.

---

## 5.4 `Catalogo` — `catalogo.h`

Gerencia **marcas** e **modelos** (cada um com sua lista + gerador de IDs).

- `adicionarMarca(nome)` — recusa nome duplicado (comparação case-insensitive).
- `adicionarModelo(marcaId, nome)` — recusa modelo duplicado **dentro da mesma marca**.
- `removerMarca(id)` / `removerModelo(id)` — devolvem o ID para reuso.
- `contarModelosDaMarca(id)` — usado para impedir remover marca que ainda tem modelos.
- `modelosDaMarca(marcaId)` — devolve um `VetorDinamico<Modelo>` para listar no cadastro.
- `carregarPadrao()` — popula um catálogo inicial (VW, Chevrolet, Fiat, ...) quando não
  há arquivo salvo.

> 🧑‍💻 **Integridade referencial:** as telas impedem remover uma **marca** com modelos,
> um **modelo** usado por carros, ou uma **categoria** com veículos. Isso evita
> "referências órfãs".

---

## 5.5 `Consultas` — `consultas.h`

Funções puras de **buscar/filtrar/ordenar**, separadas dos gerenciadores. Todas devolvem
um `VetorDinamico` pronto para a tela exibir.

| Função | O que faz | Técnica |
|--------|-----------|---------|
| `historicoPorCliente(id, loc)` | locações do cliente, mais recentes primeiro | filtra + Merge Sort |
| `historicoPorVeiculo(id, loc)` | locações do veículo | filtra + Merge Sort |
| `locacoesAtivasOrdenadas(loc)` | ativas, mais antigas primeiro | filtra + Merge Sort |
| `locacoesEmAtraso(loc)` | ativas com `agora > dataFimPrevista` | filtra + Merge Sort |
| `buscarLocacaoPorId(vetor, id)` | **ordena por id + Busca Binária** | O(n log n) + O(log n) |
| `todosDisponiveis(frota)` | carros disponíveis, por categoria/modelo | filtra + Merge Sort |
| `disponiveisPorCategoria(cat, frota)` | disponíveis de uma categoria | filtra |

> ⚙️ **Como criar uma nova consulta:** copie o padrão — percorra com `paraCada`, filtre
> com um `if`, `adicionar` ao `VetorDinamico`, ordene com `Ordenacao::ordenar` e
> `return`.

---

## 5.6 `Persistencia` — `persistencia.h`

Salva e carrega cada entidade em CSV. Detalhado em → [08 — Persistência](08-persistencia.md).

## 5.7 `contrato_pdf` — `contrato_pdf.h`

Gera os documentos jurídicos em PDF. Detalhado em → [07 — Geração de PDF](07-geracao-de-pdf.md).

Continue em → [06 — Interface e Dashboard](06-interface-e-dashboard.md)
