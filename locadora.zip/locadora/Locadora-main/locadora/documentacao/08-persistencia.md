# 08 — Persistência (arquivos)

Arquivo: `servicos/persistencia.h` (namespace `Persistencia`).

O sistema guarda os dados em **arquivos CSV** na pasta `dados/`. Não há banco de dados —
basta copiar a pasta para "levar" o sistema com seus dados.

---

## 8.1 Os arquivos

| Arquivo | Conteúdo | Colunas |
|---------|----------|---------|
| `dados/carros.csv` | frota | `id,marca,modelo,placa,ano,categoriaId,diaria,status` |
| `dados/clientes.csv` | clientes | `id,nome,cpf,telefone,email,ativo` |
| `dados/locacoes.csv` | locações | `id,idCliente,idCarro,dataInicio,dataFimPrevista,dataFimReal,valorTotal,status,multa` |
| `dados/marcas.csv` | marcas | `id,nome` |
| `dados/modelos.csv` | modelos | `id,marcaId,nome` |
| `dados/categorias.csv` | categorias | `id,nome,descricao,diaria` |

> 👶 **O que é CSV?** "Comma-Separated Values" — texto simples onde cada linha é um
> registro e as colunas são separadas por vírgula. Abre no Excel, no bloco de notas, em
> qualquer lugar.

---

## 8.2 Como salvar e carregar

Para cada entidade há um par de funções, por exemplo:
```cpp
bool salvarCarros(ListaEncadeada<Carro>& frota);   // grava o CSV
bool carregarCarros(ListaEncadeada<Carro>& frota, int& proximoId);  // lê o CSV
```

### Escrita (trecho)
```cpp
f << "id,marca,modelo,placa,ano,categoriaId,diaria,status\n";  // cabeçalho
frota.paraCada([&](Carro& c) {
    f << c.id << "," << campo(c.marca) << "," << campo(c.modelo) << ","
      << campo(c.placa) << "," << c.ano << "," << c.categoriaId << ","
      << c.diaria << "," << (int)c.status << "\n";
});
```
`campo(s)` envolve o texto em aspas (`"..."`) para escapar vírgulas dentro do valor.

### Leitura (trecho)
```cpp
std::getline(f, linha);                       // pula o cabeçalho
while (std::getline(f, linha)) {              // uma linha por registro
    std::istringstream ss(linha);
    Carro c;
    std::getline(ss, tmp, ','); c.id = std::stoi(tmp);
    c.marca = lerCampo(ss);                    // lerCampo trata as aspas
    ...
}
```

---

## 8.3 Compatibilidade: a coluna `multa`

A coluna `multa` foi adicionada depois. Para **não quebrar arquivos antigos**, a leitura
é tolerante:
```cpp
std::getline(ss, tmp, ','); l.status = (StatusLocacao)std::stoi(tmp);
if (std::getline(ss, tmp) && !tmp.empty()) l.multa = std::stod(tmp);  // opcional
```
Se a coluna não existir (arquivo antigo), `multa` simplesmente fica `0.0`.

> 🧑‍💻 **Lição de design:** ao evoluir um formato de arquivo, **adicione colunas no
> final** e leia-as de forma opcional. Assim versões novas leem arquivos velhos.

---

## 8.4 Quando salva e quando carrega (em `main.cpp`)

- **Ao iniciar:** se existe `dados/carros.csv`, chama `carregarTudo(...)`; senão, carrega
  **dados de demonstração** (6 carros, 3 clientes) para o sistema não abrir vazio.
- **Categorias:** se existe `categorias.csv`, ele **substitui** as 6 categorias padrão
  pelas salvas (evita duplicar). Se não existe, mantém as padrão e cria o arquivo no
  próximo salvamento.
- **Ao sair / opção "Salvar":** grava todos os CSVs.
- **Salvamento imediato:** ao registrar um **atraso com multa**, o `locacoes.csv` é salvo
  na hora (garante que o dado financeiro não se perca).

### Reconciliação de consistência
Logo após carregar, `GerenciadorLocacoes::reconciliarFrota()` confere se o status de cada
carro bate com as locações ativas e corrige divergências (ver [05](05-servicos-logica-de-negocio.md)).

---

## 8.5 A pasta `juridico/`

Separada dos dados: guarda os **PDFs** de contratos e aditivos (ver
[07](07-geracao-de-pdf.md)). Também é criada automaticamente.

> ⚠️ **Onde as pastas aparecem?** `dados/` e `juridico/` são criadas **no diretório de
> onde você executa o programa**. Pelo terminal, é a pasta atual; pela IDE (CLion), pode
> ser a pasta de build (`cmake-build-debug/`). Mesma lógica para ambas.

Continue em → [09 — Fluxos Passo a Passo](09-fluxos-passo-a-passo.md)
