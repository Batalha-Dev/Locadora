# 04 — Modelos de Dados

Os modelos (`modelos/`) são **structs simples** — só guardam dados, sem regras de
negócio. São o vocabulário do sistema: o que é um carro, um cliente, uma locação.

> 👶 **struct vs class:** em C++ são quase a mesma coisa; usamos `struct` aqui porque os
> dados são públicos e a intenção é "um pacotinho de campos".

---

## 4.1 `Carro` — `carro.h`

```cpp
enum class StatusCarro { DISPONIVEL, LOCADO, MANUTENCAO, RESERVADO };

struct Carro {
    int id;                 // ID único automático
    std::string modelo;     // ex.: "Gol"
    std::string marca;      // ex.: "Volkswagen"
    std::string placa;      // ex.: "ABC-1234" (chave da hash)
    int ano;                // ano do veículo (validado: atual ou 2 anteriores)
    int categoriaId;        // qual categoria (define a diária)
    double diaria;          // valor por dia (copiado da categoria no cadastro)
    StatusCarro status;     // estado atual
    std::string statusStr() const;  // status em texto ("Disponivel", ...)
};
```

- **`enum class`** dá nomes legíveis aos estados, em vez de números soltos. O compilador
  ajuda a não esquecer um caso.
- **`statusStr()`** converte o enum em texto para mostrar na tela.

> ⚙️ **Como adicionar um campo (ex.: cor):** adicione `std::string cor;`, atualize o
> construtor, a persistência (`persistencia.h`, salvar/carregar) e as telas que exibem o
> carro. Veja a receita completa em [11](11-receitas-como-modificar.md).

---

## 4.2 `Cliente` — `cliente.h`

```cpp
struct Cliente {
    int id;
    std::string nome;       // nome + sobrenome juntos
    std::string cpf;        // formatado "000.000.000-00" (chave da hash)
    std::string telefone;
    std::string email;
    bool ativo;             // marcação lógica (reservado para "soft delete")
};
```

O CPF é a chave de indexação na hash de clientes. O cadastro pede **nome** e
**sobrenome** separadamente e os junta (ver `validacao.h`).

---

## 4.3 `Locacao` — `locacao.h` (o coração do negócio)

```cpp
enum class StatusLocacao { ATIVA, CONCLUIDA, CANCELADA };

struct Locacao {
    int id;
    int idCliente;          // qual cliente alugou
    int idCarro;            // qual carro
    time_t dataInicio;      // retirada (timestamp Unix)
    time_t dataFimPrevista; // devolução prevista
    time_t dataFimReal;     // devolução efetiva (0 enquanto ativa)
    double valorTotal;      // valor das diárias
    double multa = 0.0;     // multa por atraso (preenchida na devolução em atraso)
    StatusLocacao status;
};
```

### Regras de cobrança (métodos do próprio modelo)
Centralizar as regras aqui garante que **tela e persistência usem o mesmo cálculo**.

```cpp
// Dias cobrados: mínimo 1, e qualquer fração de dia conta como dia cheio (teto).
int diasCobrados(time_t fim) const {
    if (fim <= dataInicio) return 1;
    long long seg = (long long)(fim - dataInicio);
    int dias = (int)(seg / 86400);          // 86400 = segundos em 1 dia
    if (seg % 86400 != 0) dias++;            // sobrou fração → cobra dia cheio
    return dias < 1 ? 1 : dias;
}

double valorCobrado(double diaria, time_t fim) const {
    return diasCobrados(fim) * diaria;
}

// Dias de atraso em relação à devolução prevista (0 se não houver atraso).
int diasAtraso(time_t fim) const {
    if (fim <= dataFimPrevista) return 0;
    long long seg = (long long)(fim - dataFimPrevista);
    int dias = (int)(seg / 86400);
    if (seg % 86400 != 0) dias++;
    return dias;
}
```

> 👶 **Por que `time_t`?** É um número que representa data/hora como "segundos desde
> 1970". Comparar e subtrair datas vira aritmética simples (diferença em segundos ÷
> 86400 = dias).

> 🧑‍💻 **Política de multa** (em `gerenciador_locacoes.h`): `multa = diasAtraso × diaria
> × 0,30` (30% da diária por dia de atraso). O campo `multa` é separado do `valorTotal`
> para o módulo Financeiro poder somá-los independentemente.

---

## 4.4 `Categoria` — `categoria.h`

```cpp
struct Categoria {
    int id;
    std::string nome;          // ex.: "SUV"
    std::string descricao;
    double diariaPadrao;       // diária aplicada aos carros dessa categoria
};
```

A categoria **define a diária**. Ao cadastrar um carro, a diária da categoria é copiada
para o carro. As categorias vivem numa `ListaEstatica` dentro do `GerenciadorFrota`.

---

## 4.5 `Marca` e `Modelo` — `marca.h`

```cpp
struct Marca  { int id; std::string nome; };
struct Modelo { int id; int marcaId; std::string nome; };  // modelo pertence a uma marca
```

Formam o **catálogo**: cada `Modelo` aponta para sua `Marca` via `marcaId`. No cadastro
de carro, o usuário escolhe da lista (não digita texto livre), evitando erros de digitação.

---

## 4.6 `Operacao` — `operacao.h` (para o "Desfazer")

```cpp
enum class TipoOp {
    CADASTRAR_CARRO, REMOVER_CARRO, CADASTRAR_CLIENTE, REMOVER_CLIENTE,
    REGISTRAR_LOCACAO, REGISTRAR_DEVOLUCAO, CANCELAR_LOCACAO
};

struct Operacao {
    TipoOp tipo;            // que tipo de ação foi
    int idReferencia;       // id do registro afetado
    std::string descricao;  // texto para mostrar ao desfazer
    time_t timestamp;
};
```

Cada ação reversível vira um `Operacao` empilhado. O "desfazer" tira o topo da pilha e
aplica a reversão correspondente ao `tipo` (ver `gerenciador_locacoes.h`).

> ℹ️ A **renovação** e a **devolução com multa** não criam um tipo próprio de undo
> (decisão de escopo): renovar não é revertido pelo "desfazer".

Continue em → [05 — Serviços (Lógica de Negócio)](05-servicos-logica-de-negocio.md)
