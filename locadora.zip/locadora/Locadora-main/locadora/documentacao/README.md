# 📚 Documentação — Sistema Locadora de Veículos

Bem-vindo(a) à documentação completa do **Locadora**, um sistema de gerenciamento de
locação de veículos escrito em **C++17**, com estruturas de dados implementadas do zero
(sem `std::vector`, `std::list` etc.).

Esta documentação foi escrita para **dois públicos ao mesmo tempo**:

- 👶 **Iniciante** — cada conceito é explicado em linguagem simples, com analogias e o
  "porquê" de cada decisão. Procure os blocos **"Em miúdos"**.
- 🧑‍💻 **Técnico** — há trechos de código comentados, análise de complexidade (Big O),
  detalhes de implementação e instruções de "como modificar".

---

## 🗺️ Mapa da documentação

| # | Arquivo | O que você aprende |
|---|---------|--------------------|
| — | [README.md](README.md) | Este índice + visão rápida |
| 01 | [01-visao-geral-e-arquitetura.md](01-visao-geral-e-arquitetura.md) | O que o sistema faz, as 4 camadas, como tudo se conecta |
| 02 | [02-estruturas-de-dados.md](02-estruturas-de-dados.md) | Lista encadeada, hash, pilha, fila, vetor dinâmico, lista estática, gerador de IDs |
| 03 | [03-algoritmos-ordenacao-busca.md](03-algoritmos-ordenacao-busca.md) | Merge Sort e Busca Binária, passo a passo |
| 04 | [04-modelos-de-dados.md](04-modelos-de-dados.md) | `Carro`, `Cliente`, `Locacao`, `Categoria`, `Marca`/`Modelo`, `Operacao` |
| 05 | [05-servicos-logica-de-negocio.md](05-servicos-logica-de-negocio.md) | Gerenciadores de frota, clientes, locações, catálogo e consultas |
| 06 | [06-interface-e-dashboard.md](06-interface-e-dashboard.md) | Console, componente de tabela (dashboard), validação, telas e menus |
| 07 | [07-geracao-de-pdf.md](07-geracao-de-pdf.md) | Como geramos contratos e aditivos em PDF sem bibliotecas |
| 08 | [08-persistencia.md](08-persistencia.md) | Arquivos CSV, salvar/carregar, reconciliação de consistência |
| 09 | [09-fluxos-passo-a-passo.md](09-fluxos-passo-a-passo.md) | O caminho completo de cada operação (locar, devolver, multar...) |
| 10 | [10-build-execucao-e-testes.md](10-build-execucao-e-testes.md) | Compilar (CMake/Makefile/g++), rodar e testar |
| 11 | [11-receitas-como-modificar.md](11-receitas-como-modificar.md) | Receitas práticas: adicionar campo, tela, regra, etc. |
| 12 | [12-glossario.md](12-glossario.md) | Glossário de termos para iniciantes |

> **Sugestão de leitura:** se você é iniciante, leia na ordem 01 → 12 → 02. Se é técnico
> e quer mexer no código rápido, vá para 01 → 05 → 11.

---

## ⚡ Visão rápida (TL;DR)

**O que é:** um programa de terminal que gerencia uma locadora — cadastra carros e
clientes, registra locações e devoluções, controla atrasos com multa, emite contratos
em PDF e mostra um painel financeiro.

**Como executar (resumo):**

```bash
cd locadora
g++ -std=c++17 -O2 -o locadora main.cpp   # compila tudo (headers incluídos pelo main)
./locadora                                # executa
```

**Estrutura de pastas:**

```
locadora/
├── main.cpp            ← ponto de entrada (menus de nível superior)
├── modelos/            ← structs de dados puros (Carro, Cliente, Locacao, ...)
├── estruturas/         ← estruturas genéricas (lista, hash, pilha, fila, vetor, ...)
├── servicos/           ← regras de negócio (frota, clientes, locações, PDF, persistência)
├── ui/                 ← interface (console, tabela/dashboard, validação, telas)
├── testes/             ← testes automatizados
├── dados/              ← arquivos CSV gerados em tempo de execução
├── juridico/           ← contratos e aditivos em PDF gerados em tempo de execução
└── documentacao/       ← você está aqui
```

**Principais conceitos aplicados:**

- Estruturas: **lista duplamente encadeada**, **tabela hash** (djb2 + encadeamento),
  **pilha** (LIFO), **fila** (FIFO), **vetor dinâmico**, **lista estática**.
- Algoritmos: **Merge Sort** (O(n log n)) e **Busca Binária** (O(log n)).
- Armazenamento: **arquivos CSV** + **geração de PDF feita na mão**.
- Boas práticas: **templates genéricos**, **separação em camadas**, **validação de
  entrada** e **tratamento de exceções**.

---

## 🧭 Convenções desta documentação

- 📁 caminhos de arquivo aparecem assim: `servicos/gerenciador_frota.h`.
- Blocos **"Em miúdos"** = explicação para iniciantes.
- Blocos **"Como modificar"** = passo a passo para alterar o comportamento.
- `Big O` = notação de complexidade (veja o [glossário](12-glossario.md)).
