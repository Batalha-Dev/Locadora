# 06 — Interface e Dashboard

A camada `ui/` é tudo que o usuário vê e toca. São quatro arquivos: `console.h` (utilidades
de terminal), `tabela.h` (o dashboard), `validacao.h` (validação de entrada) e `telas.h`
(as telas de cada operação).

---

## 6.1 `console.h` — utilidades de terminal

### Cores ANSI
```cpp
namespace Cor {
    const std::string VERDE = "\033[32m";   // sequências de escape ANSI
    const std::string RESET = "\033[0m";    // volta à cor normal
    // ... VERMELHO, AMARELO, AZUL, CIANO, CINZA, NEGRITO
}
```
> 👶 **O que é isso?** `\033[32m` é um "código secreto" que o terminal entende como
> "pinte o texto de verde". Sempre fechamos com `RESET` para não vazar a cor.

### Funções principais
| Função | O que faz |
|--------|-----------|
| `limpar()` | limpa a tela |
| `cabecalho(titulo)` | limpa e desenha o cabeçalho "LOCADORA CLAUDIO - <titulo>" |
| `sucesso/erro/aviso/info(msg)` | mensagens coloridas padronizadas |
| `lerInteiro(prompt)` | lê um número com segurança (rejeita texto, trata EOF) |
| `lerTexto(prompt)` | lê uma linha de texto |
| `lerTextoValidado(prompt, validador)` | lê e repete até passar no validador |
| `pausar()` | espera o usuário digitar **0** para voltar |
| `formatarMoeda(v)` | `R$ 1234.50` |
| `formatarData(t)` | `dd/mm/aaaa` a partir de um `time_t` |
| `anoAtual()` | ano corrente (para validar o ano do veículo) |

### `pausar()` — a convenção do "0 volta"
```cpp
inline void pausar() {
    while (true) {
        std::cout << "  [0] Voltar: ";
        std::string linha;
        if (!std::getline(std::cin, linha)) return;  // EOF encerra
        // remove espaços das pontas...
        if (limpo == "0") return;                     // só 0 volta
    }
}
```
> 🧑‍💻 **Por quê?** Padroniza a navegação: **0 volta** em qualquer tela, igual ao 0 que
> sai dos menus. Antes era "aperte ENTER", que exigia dois ENTERs e confundia.

---

## 6.2 `tabela.h` — o componente de Dashboard ⭐

É o que dá o visual "bonito" (tabelas emolduradas) ao sistema. Vale entender bem.

### O que ele faz
A classe `Tabela::Grade` monta uma tabela com:
- moldura arredondada em **caracteres Unicode** (`╭ ─ ┬ ┼ ╰`);
- título centralizado e cabeçalhos **coloridos por coluna** (paleta cíclica de 256 cores);
- coluna de número de linha (`#`);
- **largura automática** de cada coluna (ajusta ao maior conteúdo);
- células com cor própria (verde p/ valores, vermelho p/ atraso, ...).

### Como usar (API)
```cpp
Tabela::Grade g("CLIENTES CADASTRADOS");        // título
g.colunas({"ID", "NOME", "CPF"});                // cabeçalhos
g.larguraMinima(1, 40);                          // NOME (coluna 1) com piso de 40
g.adicionar({ Tabela::Celula("1"),
              Tabela::Celula("Ana Silva"),
              Tabela::Celula("111...", Cor::VERDE) });  // célula colorida
g.desenhar();                                    // imprime
```

### Como funciona por dentro (resumo)
1. `renderizar()` calcula a largura de cada coluna = maior conteúdo (contando
   **caracteres UTF-8**, não bytes, para acentos não desalinharem) respeitando a
   `larguraMinima`.
2. Monta as linhas de borda e de conteúdo como strings (com os códigos de cor embutidos).
3. `desenhar()` imprime; `desenharLadoALado({g1, g2, g3})` compõe vários painéis na
   **mesma faixa horizontal** (usado no Dashboard e no Financeiro).

### Detalhe avançado: texto da direita‑para‑esquerda (árabe/hebraico)
Nomes em árabe quebravam o alinhamento porque o terminal aplica o "algoritmo
bidirecional" e inverte a linha. Solução: nas linhas/células com RTL, inserimos
**marcadores de direção Unicode** (LRM/LRI…PDI) de largura zero, que isolam o texto sem
desalinhar a tabela. Isso é aplicado **somente** quando há caractere RTL (zero impacto no
caso comum).

```cpp
const std::string LRM = "\xE2\x80\x8E";  // fixa a base esquerda→direita
const std::string LRI = "\xE2\x81\xA6";  // isola início
const std::string PDI = "\xE2\x81\xA9";  // isola fim
```

> ⚙️ **Como mudar as cores:** edite `COR_BORDA`, `COR_TITULO` e a `PALETA_CAB` no topo de
> `tabela.h` (são códigos de cor ANSI de 256 níveis, `fg(n)`).

---

## 6.3 `validacao.h` — validação de entrada

Concentra todas as regras de "isso é válido?". Cada função recebe o texto e uma `string&
erro` (preenchida com a mensagem quando inválido) e retorna `bool`.

| Função | Regra |
|--------|-------|
| `validarCpf` | 11 dígitos + **dígitos verificadores reais** + rejeita repetidos |
| `validarPlaca` | padrão antigo `AAA9999` ou Mercosul `AAA9A99` |
| `validarTelefone` | DDD + 9 + 8 dígitos |
| `validarEmail` | tem `@`, domínio com ponto, sem espaços |
| `validarNomeParte` | letras (com **acentos de qualquer idioma**), espaço, hífen, apóstrofo; **rejeita números e símbolos** |
| `formatarCpf` / `formatarPlaca` / `formatarTelefone` | padronizam para exibição |

### Destaque: `validarNomeParte` (nomes internacionais)
```cpp
for (unsigned char c : t) {
    if (c >= 0x80) { temLetra = true; continue; }   // byte de letra acentuada (UTF-8) → ok
    if (letra ASCII)                  continue;       // a-z A-Z → ok
    if (c==' '||c=='-'||c=='\'')      continue;       // separadores de nome → ok
    if (dígito)  return erro "não pode conter números";
    return erro "caractere inválido";
}
```
> 🧑‍💻 **A ideia:** aceitar qualquer letra acentuada (Nováková, Dvořák, José) tratando
> bytes ≥ 0x80 como letra, e barrar dígitos/símbolos ASCII.

### Validação de ano (no cadastro de carro)
O ano só pode ser o **atual ou os 2 anteriores**. Implementado com um laço que repete até
o valor cair em `[anoAtual-2, anoAtual]`.

---

## 6.4 `telas.h` — as telas

Cada operação tem uma função `tela...`. O padrão é sempre o mesmo:

```
1. Console::cabecalho("TÍTULO")
2. (quando útil) mostrar um dashboard com os IDs disponíveis
3. ler entradas com validação / laços de re-tentativa (0 cancela)
4. chamar o serviço correspondente
5. mostrar resultado (sucesso/erro) e Console::pausar()
```

Telas notáveis:
- **Listagens** (frota, clientes, locações, catálogo) → usam `Tabela::Grade`.
- **Fichas** (`fichaCliente`, ficha de veículo) → tabela CAMPO/VALOR emoldurada.
- **Dashboard principal** (`telaDashboard`) → 3 painéis lado a lado (frota, clientes, financeiro).
- **Financeiro** (`telaFinanceiro`) → resumo + tabela de multas aplicadas.
- **Locação/Devolução/Renovação/Atraso** → mostram o dashboard relevante antes de pedir o ID.

### Tratamento de erros
As telas da aba de locações estão envoltas em `try/catch`, e o menu de locações também
tem um `try/catch` "guarda-chuva": qualquer exceção vira uma mensagem e **não derruba o
programa**.

---

## 6.5 `main.cpp` — os menus

`main.cpp` inicializa os gerenciadores, carrega os dados, exibe o **menu principal** e
encaminha para os submenus:

```
MENU PRINCIPAL
 [1] Dashboard     [2] Frota      [3] Clientes   [4] Locações
 [5] Consultas     [6] Catálogo   [7] Financeiro [8] Salvar
 [0] Sair (salva automaticamente)
```

Cada submenu (`menuFrota`, `menuClientes`, `menuLocacoes`, `menuConsultas`, `menuCatalogo`)
é um laço `do...while (op != 0)` que chama a tela conforme a opção.

Continue em → [07 — Geração de PDF](07-geracao-de-pdf.md)
