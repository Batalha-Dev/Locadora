# 12 — Glossário (para iniciantes)

Termos que aparecem na documentação e no código, explicados de forma simples.

---

**Algoritmo** — Uma receita de passos para resolver um problema (ex.: ordenar uma lista).

**Big O (notação)** — Forma de medir como o tempo (ou memória) de um algoritmo cresce
conforme a entrada aumenta. Veja a tabela abaixo.

| Notação | Nome | Em miúdos |
|---------|------|-----------|
| O(1) | constante | não importa o tamanho, é instantâneo |
| O(log n) | logarítmica | cresce devagarinho (busca binária) |
| O(n) | linear | dobra a entrada, dobra o tempo |
| O(n log n) | "n log n" | bom para ordenar (Merge Sort) |
| O(n²) | quadrática | fica lento rápido; evitamos |

**Bucket (balde)** — Cada "gaveta" de uma tabela hash. Chaves que colidem ficam na mesma
gaveta, numa listinha.

**Camada** — Um nível do sistema com uma responsabilidade (modelos, estruturas, serviços,
interface).

**Colisão (hash)** — Quando duas chaves diferentes caem no mesmo índice da tabela hash.
Resolvido com encadeamento separado (uma lista por índice).

**CSV** — "Comma-Separated Values": arquivo de texto com colunas separadas por vírgula.

**CRUD** — Create, Read, Update, Delete (criar, ler, atualizar, apagar) — as operações
básicas sobre um cadastro.

**Encadeamento separado** — Estratégia para colisões de hash: cada índice aponta para uma
lista de pares.

**Enum (`enum class`)** — Tipo com um conjunto fixo de valores nomeados (ex.: `DISPONIVEL`,
`LOCADO`). Mais legível e seguro que usar números.

**FIFO** — "First In, First Out": primeiro a entrar, primeiro a sair (fila de banco).

**Função de hash** — Transforma uma chave (texto/número) num índice de array. Ex.: djb2.

**Hash table (tabela hash)** — Estrutura que acha um valor pela chave quase
instantaneamente (O(1) médio).

**Heap** — Região de memória para alocação dinâmica (`new`/`delete`). Diferente da "pilha
de execução" do programa.

**Heredoc** — Forma de passar texto multilinha a um comando no terminal (`<<'PY' ... PY`).

**Lambda** — Função anônima escrita na hora, ex.: `[](Carro& c){ return c.id == 5; }`.
Usada como comparador (ordenação) ou predicado (busca).

**LIFO** — "Last In, First Out": último a entrar, primeiro a sair (pilha de pratos).

**Lista encadeada** — Sequência de nós ligados por ponteiros. "Duplamente" = cada nó
conhece o anterior e o próximo.

**Move constructor** — Construtor que "rouba" os recursos de um objeto temporário em vez
de copiá-los (mais rápido). Permite retornar estruturas grandes por valor.

**Nó (node)** — Cada "elo" de uma lista, pilha ou fila: guarda o dado e ponteiros.

**Ponteiro** — Variável que guarda o **endereço** de outro dado na memória. `nullptr` =
"não aponta para nada".

**Predicado** — Função que devolve verdadeiro/falso, usada para filtrar/buscar.

**Persistência** — Guardar os dados em disco para não perdê-los ao fechar o programa.

**RTL (right-to-left)** — Escrita da direita para a esquerda (árabe, hebraico). Exige
cuidado para não desalinhar tabelas no terminal.

**Status** — Estado atual de algo (carro: Disponível/Locado/Manutenção; locação:
Ativa/Concluída/Cancelada).

**STL** — Standard Template Library do C++ (`std::vector`, `std::map`, ...). Aqui
reimplementamos estruturas equivalentes **do zero**, para aprender.

**Template** — "Molde" de código genérico que funciona com qualquer tipo (`template
<typename T>`).

**time_t** — Número que representa data/hora como segundos desde 01/01/1970. Subtrair dois
`time_t` e dividir por 86400 dá a diferença em dias.

**Try/catch** — Mecanismo para capturar **exceções** (erros em tempo de execução) e tratá-
las sem derrubar o programa.

**UTF-8** — Codificação de texto onde um caractere pode ocupar 1 a 4 bytes. Por isso
contamos **caracteres**, não bytes, ao medir a largura de uma tabela.

**Vetor dinâmico** — Array que cresce sozinho (dobra de tamanho quando enche).

---

← Voltar ao [índice](README.md)
