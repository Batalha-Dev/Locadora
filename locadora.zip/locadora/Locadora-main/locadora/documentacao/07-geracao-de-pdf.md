# 07 — Geração de Documentos em PDF

Arquivo: `servicos/contrato_pdf.h` (namespace `Contrato`).

A cada **nova locação** o sistema emite um **contrato** (`juridico/contrato_<id>.pdf`) e a
cada **renovação** um **termo aditivo** (`juridico/aditivo_<id>_<n>.pdf`). Tudo é gerado
**sem bibliotecas externas** — escrevemos o arquivo PDF "na mão".

---

## 7.1 Por que escrever PDF na mão?

O requisito do projeto é não depender de bibliotecas externas. Um PDF, no fundo, é um
**arquivo de texto com uma estrutura bem definida**. Dá para gerá-lo escrevendo os bytes
certos. É educativo e mantém o projeto 100% portátil (só o compilador C++).

> 👶 **Em miúdos:** um PDF é como um documento com "etiquetas" que dizem "aqui começa uma
> página", "escreva este texto nesta posição", etc. Nós montamos essas etiquetas.

---

## 7.2 Anatomia de um PDF (o mínimo que usamos)

```
%PDF-1.4                     ← cabeçalho: versão
1 0 obj ... endobj           ← objeto 1: Catálogo (raiz)
2 0 obj ... endobj           ← objeto 2: lista de Páginas
3 0 obj ... endobj           ← objeto 3: Fonte Helvetica
4 0 obj ... endobj           ← objeto 4: Fonte Helvetica-Bold
5 0 obj ... endobj           ← objeto 5: Página 1
6 0 obj ... stream ... endobj ← objeto 6: conteúdo da página 1 (o texto)
...
xref                         ← tabela de referências (posição de cada objeto)
trailer                      ← aponta para a raiz
startxref                    ← posição da xref
%%EOF                        ← fim
```

Cada texto é desenhado dentro de um "content stream" com operadores:
```
BT                  ← begin text
/F1 12 Tf           ← fonte F1, tamanho 12
56 778 Td           ← posiciona em (x=56, y=778)  [origem é canto inferior esquerdo]
(Olá mundo) Tj      ← escreve o texto
ET                  ← end text
```

---

## 7.3 As peças do `contrato_pdf.h`

### Dados fixos da empresa (em todos os documentos)
```cpp
const std::string EMPRESA      = "Locadora Claudio Ltda.";
const std::string PROPRIETARIO = "Claudio Anthropico";
const std::string CNPJ         = "12.345.678/0001-90";   // fictício
```

### `EscritorPDF` — uma "máquina de escrever" de alto nível
Esconde a complexidade do PDF atrás de métodos simples:
```cpp
EscritorPDF pdf;
pdf.linha("CONTRATO DE LOCACAO DE VEICULO", 16, /*negrito*/true, /*centro*/true);
pdf.vazia();                                  // espaço em branco
pdf.paragrafo("Texto longo que quebra em várias linhas automaticamente...");
```
Internamente ele controla a posição `y` (de cima para baixo), **quebra de linha
automática** (word-wrap) e abre **nova página** quando o texto chega ao rodapé.

### Conversão de acentos
As fontes padrão do PDF usam codificação **WinAnsi/Latin-1**. O texto do programa é
UTF-8. Por isso convertemos:
```cpp
std::string utf8ParaLatin1(const std::string& s);  // "ção" UTF-8 → bytes Latin-1
```
Caracteres fora do Latin-1 (ex.: árabe) viram `?` — limitação das fontes padrão.

### Escape de caracteres especiais
Em PDF, `(`, `)` e `\` têm significado especial dentro de um texto e precisam de `\`:
```cpp
std::string escaparPDF(const std::string& s);  // "LOCATARIO(A)" → "LOCATARIO\(A\)"
```

### `montarPDF(streams)` — o serializador
Recebe o conteúdo de cada página e monta o arquivo completo: objetos, **tabela xref com
os deslocamentos em bytes** de cada objeto, trailer e `startxref`. É a parte "chata" do
formato, isolada numa função só.

---

## 7.4 O contrato (`gerarContratoLocacao`)

Monta um contrato jurídico com:
- Título + número do contrato;
- **Qualificação da LOCADORA** (empresa, proprietário, CNPJ);
- **Qualificação do LOCATÁRIO** (nome, CPF, telefone, e-mail);
- Descrição do **veículo**;
- **Cláusula 1ª** – Do Objeto; **2ª** – Do Prazo; **3ª** – Do Valor e Pagamento;
  **4ª** – Das Obrigações; **5ª** – Da Devolução e Multa; **6ª** – Do Foro;
- Local/data e linhas de assinatura.

Salva em `juridico/contrato_<id>.pdf` e devolve o caminho (ou string vazia em falha).

---

## 7.5 O termo aditivo (`gerarTermoAditivo`)

A renovação **não sobrescreve** o contrato original — gera um documento separado e
numerado:
- `proximoNumeroAditivo(idLocacao)` descobre o próximo número (1, 2, 3...) olhando os
  arquivos já existentes em `juridico/`.
- O aditivo referencia o contrato original, descreve o acréscimo de diárias, o novo prazo
  e o novo valor total, e **ratifica** as demais cláusulas.
- Salva em `juridico/aditivo_<id>_<n>.pdf`.

> 🧑‍💻 **Por que documento separado?** É a forma juridicamente correta: o contrato
> original permanece íntegro e o aditivo registra a alteração, preservando o histórico.

---

## 7.6 Onde é chamado

- **Nova locação** (`telaNovaLocacao`): após `registrarLocacao` dar certo →
  `Contrato::gerarContratoLocacao(...)`.
- **Renovação** (`telaRenovacao`): após `renovarLocacao` → `Contrato::gerarTermoAditivo(...)`.

> ⚙️ **Como mudar o texto/cláusulas:** edite as chamadas `pdf.linha(...)` e
> `pdf.paragrafo(...)` dentro de `gerarContratoLocacao` / `gerarTermoAditivo`. Para mudar
> a empresa/CNPJ, altere as constantes no topo do arquivo.

Continue em → [08 — Persistência](08-persistencia.md)
