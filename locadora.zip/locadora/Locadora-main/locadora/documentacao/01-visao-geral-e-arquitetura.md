# 01 — Visão Geral e Arquitetura

## 1.1 O que o sistema faz

O **Locadora** é um sistema de terminal (linha de comando) que gerencia uma locadora de
veículos. As funcionalidades principais são:

- **Frota:** cadastrar, listar, buscar (por ID ou placa), enviar para manutenção e remover veículos.
- **Catálogo:** cadastrar/remover marcas, modelos e categorias (a categoria define a diária).
- **Clientes:** cadastrar (nome + sobrenome), buscar (ID ou CPF) e remover.
- **Locações:** registrar locação, devolução, renovação de diárias, registro de atraso
  com multa, e desfazer a última operação.
- **Consultas:** disponibilidade por categoria, locações ativas, locações em atraso,
  histórico por cliente, histórico por veículo e busca binária por ID de locação.
- **Financeiro:** painel com receita de diárias, total de multas, receita prevista, etc.
- **Documentos:** gera **contrato de locação** e **termo aditivo de renovação** em PDF.
- **Persistência:** salva tudo em arquivos CSV e recarrega ao abrir.

> 👶 **Em miúdos:** pense num "caixa eletrônico" de locadora. Você navega por menus
> digitando números, e o programa cuida dos carros, clientes, aluguéis e dinheiro,
> guardando tudo em arquivos para não perder quando você fecha.

---

## 1.2 As 4 camadas (arquitetura)

O código é organizado em **camadas**, cada uma com uma responsabilidade. Isso é uma
prática de mercado: separa "o que é o dado" de "as regras" de "como mostrar na tela".

```
┌──────────────────────────────────────────────────────────┐
│  ui/         INTERFACE  (telas, menus, dashboard, validação)│  ← fala com o usuário
├──────────────────────────────────────────────────────────┤
│  servicos/   REGRAS DE NEGÓCIO (gerenciadores, consultas,   │  ← decide o que pode/não pode
│              persistência, geração de PDF)                  │
├──────────────────────────────────────────────────────────┤
│  estruturas/ ESTRUTURAS DE DADOS (lista, hash, pilha, fila, │  ← "como guardar" os dados
│              vetor, lista estática, gerador de IDs)         │
├──────────────────────────────────────────────────────────┤
│  modelos/    DADOS PUROS (Carro, Cliente, Locacao, ...)     │  ← "o que é" um carro, etc.
└──────────────────────────────────────────────────────────┘
        main.cpp  ← amarra tudo: inicializa, carrega dados e mostra os menus
```

**Regra de dependência:** as camadas de cima conhecem as de baixo, nunca o contrário.
`ui` usa `servicos`; `servicos` usa `estruturas` e `modelos`; `modelos` não depende de
ninguém. Isso mantém o `modelos` reutilizável e o sistema fácil de manter.

> 🧑‍💻 **Por que assim?** Se amanhã você trocar a interface de terminal por uma
> interface gráfica, só a camada `ui` muda. As regras (`servicos`) e os dados
> (`modelos`) continuam idênticos.

---

## 1.3 Mapa de arquivos e responsabilidades

### `modelos/` — os dados
| Arquivo | Responsabilidade |
|---------|------------------|
| `carro.h` | struct `Carro` + enum `StatusCarro` |
| `cliente.h` | struct `Cliente` |
| `locacao.h` | struct `Locacao` + enum `StatusLocacao` + regras de cobrança de data |
| `categoria.h` | struct `Categoria` (nome + diária padrão) |
| `marca.h` | structs `Marca` e `Modelo` |
| `operacao.h` | struct `Operacao` + enum `TipoOp` (para o "desfazer") |

### `estruturas/` — como guardar os dados (genéricas)
| Arquivo | Estrutura | Uso no sistema |
|---------|-----------|----------------|
| `lista_encadeada.h` | Lista duplamente encadeada | Armazena frota, clientes, locações |
| `hash_table.h` | Tabela hash (encadeamento) | Busca rápida por placa, CPF, ID |
| `pilha.h` | Pilha (LIFO) | Histórico de "desfazer" e gerador de IDs |
| `fila.h` | Fila (FIFO) | Fila de espera por categoria |
| `vetor_dinamico.h` | Array que cresce | Resultados de consultas e ordenação |
| `lista_estatica.h` | Array de tamanho fixo | Lista de categorias |
| `gerador_id.h` | Gerador de IDs | IDs automáticos reutilizáveis |
| `ordenacao.h` | Merge Sort + Busca Binária | Ordenar e buscar em consultas |

### `servicos/` — as regras de negócio
| Arquivo | Responsabilidade |
|---------|------------------|
| `gerenciador_frota.h` | CRUD de veículos, categorias, fila de espera, busca por placa/ID |
| `gerenciador_clientes.h` | CRUD de clientes, busca por CPF/ID |
| `gerenciador_locacoes.h` | Locação, devolução, renovação, multa, undo |
| `catalogo.h` | CRUD de marcas e modelos |
| `consultas.h` | Consultas analíticas (históricos, disponíveis, atrasos) |
| `persistencia.h` | Salvar/carregar arquivos CSV |
| `contrato_pdf.h` | Geração de contrato e aditivo em PDF |

### `ui/` — a interface
| Arquivo | Responsabilidade |
|---------|------------------|
| `console.h` | Cores ANSI, ler entrada, formatar moeda/data, "pausar" |
| `tabela.h` | Componente de **dashboard** (tabelas estilizadas) |
| `validacao.h` | Validação de CPF, placa, e-mail, nome, data, ano |
| `telas.h` | Todas as telas (cada operação tem a sua função) |

### Raiz
| Arquivo | Responsabilidade |
|---------|------------------|
| `main.cpp` | Inicialização, carga de dados, menus principais, salvamento ao sair |
| `CMakeLists.txt` / `Makefile` | Build do projeto |
| `testes/testes.cpp` | Testes automatizados |

---

## 1.4 Como tudo se conecta (fluxo de uma operação)

Exemplo: o usuário escolhe **"Nova locação"**.

```
main.cpp (menu)
   └─> ui/telas.h : telaNovaLocacao(...)
          ├─> mostra dashboards (ui/tabela.h) com clientes e carros disponíveis
          ├─> lê e valida a entrada (ui/console.h)
          ├─> chama servicos/gerenciador_locacoes.h : registrarLocacao(...)
          │       ├─> verifica regras (carro disponível? cliente já tem locação ativa?)
          │       ├─> usa estruturas/ (lista + hash) para guardar/indexar
          │       └─> empilha a operação na pilha de "desfazer"
          └─> chama servicos/contrato_pdf.h : gerarContratoLocacao(...) → PDF
```

> 👶 **Em miúdos:** a tela é o "garçom" que conversa com você; o gerenciador é a
> "cozinha" que aplica as regras; as estruturas são as "prateleiras" onde os dados
> ficam guardados.

---

## 1.5 Por que C++ e por que "do zero"?

- **C++17**: linguagem rápida, com **templates** (código genérico) e controle de memória.
- **Estruturas do zero (sem STL containers):** o objetivo acadêmico é *entender por
  dentro* como uma lista encadeada ou uma hash funcionam — algo que a `std::list`/
  `std::unordered_map` escondem. Em produção real, usaríamos a STL; aqui, reimplementamos
  para aprender.

Continue em → [02 — Estruturas de Dados](02-estruturas-de-dados.md)
