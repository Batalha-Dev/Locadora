# 09 — Fluxos Passo a Passo

Aqui seguimos o caminho **completo** de cada operação, do menu até o disco. Útil para
entender como as camadas colaboram e para depurar.

---

## 9.1 Nova locação

```
Menu Locações → [4] Nova locação  →  ui/telas.h : telaNovaLocacao
```
1. Mostra o **dashboard de clientes** (`gradeClientes`) para você ver os IDs.
2. Lê o **ID do cliente** num laço (0 cancela; repete se não existir).
3. Mostra o **dashboard de veículos disponíveis** (`gradeVeiculosDisponiveis`).
4. Lê o **ID do veículo** (se não estiver disponível, oferece **fila de espera**).
5. Lê a **quantidade de dias** (> 0).
6. Mostra o resumo (datas previstas e valor estimado) e pede confirmação.
7. Chama `GerenciadorLocacoes::registrarLocacao`:
   - valida (carro disponível? cliente sem locação ativa?);
   - cria a `Locacao`, marca o carro como `LOCADO`, empilha a operação (undo).
8. Gera o **contrato PDF** (`Contrato::gerarContratoLocacao`).
9. `pausar()` (0 volta).

Tudo dentro de `try/catch` — erros viram mensagem, não travam o programa.

---

## 9.2 Devolução (normal)

```
Menu Locações → [5] Registrar devolução  →  telaDevolucao
```
1. Mostra o dashboard de **locações ativas**.
2. Lê o ID (valida: existe? está ativa?).
3. Mostra o cálculo: dias reais, valor final, aviso se em atraso.
4. Confirma → `registrarDevolucao`:
   - `dataFimReal = agora`, status `CONCLUIDA`;
   - **recalcula** o valor pelos dias reais (`valorCobrado`);
   - marca o carro `DISPONIVEL` e chama o próximo da fila de espera.

> ℹ️ A devolução normal **não** aplica multa. Para cobrar multa por atraso, use a aba
> específica (9.4).

---

## 9.3 Renovação de diárias

```
Menu Locações → [6] Renovar diárias  →  telaRenovacao
```
1. Dashboard de **locações ativas** → escolhe o ID.
2. Lê as **diárias a adicionar** (> 0).
3. Mostra prévia (acréscimo, nova devolução, novo total) e confirma.
4. `renovarLocacao`: estende `dataFimPrevista` e soma ao `valorTotal`.
5. Gera um **Termo Aditivo** PDF separado (`gerarTermoAditivo`).

---

## 9.4 Registrar atraso (com multa)

```
Menu Locações → [7] Registrar atraso  →  telaRegistrarAtraso
```
1. Dashboard de **locações em atraso** (`Consultas::locacoesEmAtraso`).
2. Lê o ID (valida: existe? ativa? **realmente em atraso**?).
3. `calcularAtraso` faz a **prévia** (sem efetivar): dias de atraso, valor das diárias,
   **multa = diasAtraso × diária × 0,30**, e total.
4. Mostra um **dashboard com os dados do atraso** (cliente, veículo, valores, multa, total).
5. Confirma → `registrarDevolucaoComMulta`: grava `multa`, conclui a locação, libera o carro.
6. **Salva o `locacoes.csv` imediatamente** (dado financeiro garantido).

---

## 9.5 Financeiro

```
Menu Principal → [7] Financeiro  →  telaFinanceiro
```
- **Resumo:** receita de diárias (`receitaTotal`), total de multas (`receitaMultas`),
  receita total (soma), receita prevista (ativas), nº de ativas e em atraso.
- **Tabela "Multas aplicadas":** lista as locações concluídas com `multa > 0`.

---

## 9.6 Desfazer (undo)

```
Menu Locações → [8] Desfazer última operação
```
- `desfazerUltima()` tira a última `Operacao` da pilha e reverte conforme o tipo
  (cancela locação criada, reabre devolução, etc.).

---

## 9.7 Inicialização e encerramento (em `main.cpp`)

**Início:**
```
1. habilita cores (Windows)
2. tenta carregar dados/ (senão, carrega demonstração)
3. se não há categorias salvas, mantém as 6 padrão; senão usa as do arquivo
4. reconciliarFrota() corrige inconsistências
5. entra no laço do menu principal
```
**Saída (opção 0):** grava todos os CSVs automaticamente.

---

## 9.8 Análise de eficiência e limitações

- **Buscas por placa/CPF/ID:** O(1) médio (hash) — escalam bem.
- **Listagens e consultas:** O(n) para filtrar + O(n log n) para ordenar.
- **Busca binária:** O(log n), demonstrada na consulta por ID de locação.

**Limitações conhecidas:**
- A hash **não redimensiona** sozinha (fator de carga pode subir em bases enormes).
- As fontes do PDF cobrem só o alfabeto latino (nomes em árabe/cirílico saem como `?` no
  documento, embora apareçam certos no terminal).
- Interface é de terminal (sem GUI).

Continue em → [10 — Build, Execução e Testes](10-build-execucao-e-testes.md)
