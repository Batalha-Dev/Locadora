# 11 — Receitas: Como Modificar o Sistema

Receitas práticas, passo a passo, para as alterações mais comuns. Cada uma indica
**quais arquivos tocar** e por quê.

---

## 11.1 Adicionar um campo a uma entidade (ex.: cor do carro)

1. **Modelo** (`modelos/carro.h`): adicione `std::string cor;` e inclua no construtor.
2. **Persistência** (`servicos/persistencia.h`):
   - em `salvarCarros`, acrescente `<< "," << campo(c.cor)` (no **final** da linha) e a
     coluna no cabeçalho;
   - em `carregarCarros`, leia o novo campo; deixe-o **opcional** (como a `multa`) para
     não quebrar arquivos antigos.
3. **Cadastro** (`ui/telas.h` → `telaCadastrarCarro`): leia/valide a cor.
4. **Exibição** (listagens/fichas): adicione a coluna na `Tabela::Grade`.

> 💡 Regra de ouro: **colunas novas vão no fim do CSV** e são lidas de forma opcional.

---

## 11.2 Mudar a política de multa por atraso

Arquivo: `servicos/gerenciador_locacoes.h`.
```cpp
const double FATOR_MULTA_DIA = 0.30;   // 30% da diária por dia de atraso
```
- Para 50%: troque por `0.50`.
- Para uma **multa fixa** + diária: edite `calcularAtraso` (ex.:
  `r.multa = 50.0 + r.diasAtraso * diaria * 0.20;`).
- A tela e o financeiro usam os valores calculados — não precisam mudar.

---

## 11.3 Mudar a regra do ano do veículo

Arquivo: `ui/telas.h` → `telaCadastrarCarro`. Hoje:
```cpp
int anoMin = Console::anoAtual() - 2;   // ano atual ou 2 anteriores
```
Para aceitar 5 anos, troque `- 2` por `- 5`. A mensagem se ajusta sozinha.

---

## 11.4 Adicionar uma nova categoria padrão

Arquivo: `servicos/gerenciador_frota.h` → `carregarCategoriasPadrao()`:
```cpp
categorias.inserir({6, "Esportivo", "Carros esportivos", 500.0});
```
⚠️ Aumente também `MAX_CATEGORIAS` se passar de 6. (Ou cadastre em tempo de execução pelo
menu **Frota → Cadastrar categoria**, que já persiste em `categorias.csv`.)

---

## 11.5 Criar uma nova tela/consulta

1. **Consulta** (se precisar buscar/ordenar): adicione uma função em
   `servicos/consultas.h` seguindo o padrão (percorre → filtra → `adicionar` → `ordenar`
   → `return`).
2. **Tela** (`ui/telas.h`): crie `inline void telaXXX(...)`, use `Console::cabecalho`,
   monte um `Tabela::Grade` e `desenhar()`, finalize com `Console::pausar()`.
3. **Menu** (`main.cpp`): adicione a opção no submenu e um `case` no `switch`.

> 🧩 Copie uma tela parecida (ex.: `telaListarClientes`) como ponto de partida.

---

## 11.6 Mudar as cores/estilo das tabelas

Arquivo: `ui/tabela.h`, no topo:
```cpp
const std::string COR_BORDA  = fg(60);   // cor da moldura
const std::string COR_TITULO = fg(39);   // cor do título
const std::vector<std::string> PALETA_CAB = { fg(203), fg(215), ... }; // cabeçalhos
```
`fg(n)` é uma cor ANSI 256 (0–255). Troque os números para mudar o tema.

Para uma coluna mais larga: `g.larguraMinima(indiceDaColuna, larguraMinima);`.

---

## 11.7 Mudar o texto do contrato ou os dados da empresa

Arquivo: `servicos/contrato_pdf.h`.
- **Empresa/CNPJ:** edite as constantes `EMPRESA`, `PROPRIETARIO`, `CNPJ`.
- **Cláusulas/texto:** edite as chamadas `pdf.linha(...)` e `pdf.paragrafo(...)` em
  `gerarContratoLocacao` / `gerarTermoAditivo`.

---

## 11.8 Aumentar a capacidade da tabela hash

Arquivo: `estruturas/hash_table.h`, construtor:
```cpp
explicit HashTable(int cap = 53)   // troque 53 por outro número PRIMO maior
```
Ou passe a capacidade ao criar a hash no gerenciador. Use sempre **número primo**.

---

## 11.9 Erros comuns ao modificar

| Sintoma | Causa provável | Solução |
|---------|----------------|---------|
| "undefined reference" no link | esqueceu de incluir um `.h` | adicione o `#include` |
| dados não salvam | escreveu no CSV mas não leu (ou vice-versa) | sincronize salvar **e** carregar |
| tabela desalinhada | contou bytes em vez de caracteres | a `Tabela::Grade` já trata UTF-8; não meça largura na mão |
| carro "fantasma" locado | editou CSV na mão e quebrou consistência | a `reconciliarFrota()` corrige no próximo start |
| ID repetido após remover | `reutilizarId` ligado com histórico vivo | use `reutilizarId = false` quando houver histórico |

Continue em → [12 — Glossário](12-glossario.md)
