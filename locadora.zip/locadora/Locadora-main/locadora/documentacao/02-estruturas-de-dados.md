# 02 — Estruturas de Dados

Todas as estruturas estão em `estruturas/` e são **templates** (`template <typename T>`),
ou seja, funcionam com qualquer tipo de dado. A mesma `ListaEncadeada` guarda `Carro`,
`Cliente` ou `Locacao`.

> 👶 **O que é template?** É um "molde". Você escreve a estrutura uma vez e o compilador
> gera uma versão para cada tipo que você usar. `ListaEncadeada<Carro>` e
> `ListaEncadeada<Cliente>` são a mesma lógica, com tipos diferentes.

---

## 2.1 Lista Duplamente Encadeada — `lista_encadeada.h`

### O que é
Uma sequência de **nós**. Cada nó guarda um dado e **dois ponteiros**: um para o nó
**anterior** e outro para o **próximo**.

```
nullptr ← [A] ⇄ [B] ⇄ [C] → nullptr
          cabeça        cauda
```

### Por que usamos
É a **estrutura principal de armazenamento** (frota, clientes, locações). Inserir no fim
é instantâneo (temos o ponteiro `cauda`), e conseguimos percorrer em qualquer direção.

### Como funciona (trecho comentado)
```cpp
struct No {
    T dado;            // o dado em si (um Carro, por exemplo)
    No* anterior;      // aponta para o nó de trás
    No* proximo;       // aponta para o nó da frente
};

No* cabeca;   // primeiro nó
No* cauda;    // último nó
int tamanho;  // quantos nós existem

void inserirFim(const T& dado) {
    No* novo = new No(dado);
    if (!cauda) { cabeca = cauda = novo; }   // lista vazia: novo é o único
    else {
        novo->anterior = cauda;              // liga o novo atrás da cauda atual
        cauda->proximo = novo;               // a cauda atual aponta pra frente
        cauda = novo;                        // o novo vira a nova cauda
    }
    tamanho++;
}
```

Métodos importantes:
- `inserirFim` / `inserirInicio` — **O(1)** (instantâneo).
- `buscar(pred)` — recebe uma **função** (lambda) e devolve o primeiro elemento que
  satisfaz. Ex.: `lista.buscar([](Carro& c){ return c.id == 5; })`. **O(n)**.
- `removerSe(pred)` — remove o primeiro que satisfaz o predicado. **O(n)**.
- `paraCada(func)` — executa `func` em cada elemento (como um `for-each`). **O(n)**.

### Detalhe técnico importante
A cópia foi **proibida** de propósito:
```cpp
ListaEncadeada(const ListaEncadeada&) = delete;
```
Isso evita o bug clássico de copiar a lista e dois objetos apontarem para os mesmos nós
(causando "double free" ao destruir). Por isso passamos listas sempre por **referência**
(`&`).

> ⚙️ **Como modificar:** para listar do mais novo para o mais velho, percorra a partir
> da `cauda` usando `anterior` (hoje só há `paraCada` do início ao fim).

---

## 2.2 Tabela Hash — `hash_table.h`

### O que é
Uma estrutura que mapeia uma **chave** (placa, CPF, ID) para um **valor**, com busca
quase instantânea. Internamente é um array de "baldes" (buckets); uma **função de hash**
transforma a chave num índice do array.

```
chave "ABC-1234"  ──hash──>  índice 17  ──>  [par: ABC-1234 → id 3]
```

### Por que usamos
Buscar um carro pela placa numa lista encadeada custa **O(n)** (olhar um por um). Com
hash, custa **O(1)** em média. Como a locadora busca por placa/CPF o tempo todo, vale a
pena manter um índice hash em paralelo à lista.

### Como funciona — função de hash (trecho comentado)
```cpp
// djb2: clássico para strings. Multiplica por 33 e soma cada caractere.
int calcularHash(const std::string& chave) const {
    unsigned long h = 5381;
    for (char c : chave) h = h * 33 + (unsigned char)c;
    return (int)(h % capacidade);   // espreme no tamanho do array
}

// Para inteiros: resto da divisão (com ajuste para não dar negativo)
int calcularHash(int chave) const {
    return ((chave % capacidade) + capacidade) % capacidade;
}
```

### Colisões: encadeamento separado
Duas chaves diferentes podem cair no mesmo índice (colisão). Solução: cada posição do
array aponta para uma **lista encadeada** de pares. Na busca, percorremos só aquela
listinha.

```cpp
struct Par { K chave; V valor; Par* proximo; };  // mini-lista por balde
Par** buckets;  // array de ponteiros para Par
```

- `inserir(chave, valor)` — se a chave existe, atualiza; senão, insere no início do
  balde. **O(1)** médio.
- `buscar(chave)` — devolve ponteiro para o valor, ou `nullptr`. **O(1)** médio.
- `fatorCarga()` = tamanho / capacidade. Ideal **< 0,75**.

A capacidade padrão é **53** (número primo — reduz colisões).

> ⚙️ **Como modificar a capacidade:** mude o `cap = 53` no construtor. Use sempre um
> **número primo**. ⚠️ **Limitação:** esta hash **não cresce sozinha**; para bases muito
> grandes o desempenho cai (veja "Limitações" em [09](09-fluxos-passo-a-passo.md)).

---

## 2.3 Pilha (LIFO) — `pilha.h`

### O que é
"Last In, First Out": o último a entrar é o primeiro a sair, como uma pilha de pratos.

```
empilhar(C) →  [C]   ← topo
               [B]
               [A]
desempilhar()  devolve C
```

### Por que / onde usamos
1. **Desfazer (undo):** cada operação vira um registro empilhado; "desfazer" tira o do
   topo e reverte.
2. **Gerador de IDs:** IDs livres ficam empilhados para reuso (ver 2.6).

```cpp
void empilhar(const T& dado);   // O(1)
T    desempilhar();             // O(1) — lança exceção se vazia
const T& espiar() const;        // olha o topo sem remover
```

> 👶 **Por que pilha para "desfazer"?** Porque desfazer é sempre da **última** ação para
> trás — exatamente a ordem LIFO.

---

## 2.4 Fila (FIFO) — `fila.h`

### O que é
"First In, First Out": o primeiro a entrar é o primeiro a sair, como uma fila de banco.

### Por que / onde usamos
A **fila de espera por categoria**: se todos os carros "SUV" estão locados, o cliente
entra na fila e será atendido na ordem de chegada quando um SUV voltar.

```cpp
void enfileirar(const T& dado);  // entra no fundo — O(1)
T    desenfileirar();            // sai da frente — O(1)
```

---

## 2.5 Vetor Dinâmico — `vetor_dinamico.h`

### O que é
Um array que **dobra de tamanho** automaticamente quando enche. Acesso por índice é
**O(1)**.

```cpp
void adicionar(const T& item) {
    if (tamanho == capacidade) redimensionar();  // dobra a capacidade
    dados[tamanho++] = item;
}
T& operator[](int i);  // acesso por índice, com checagem de limites
```

### Por que usamos
É a base para **ordenação** (Merge Sort) e **busca binária**. Quando uma consulta
precisa ordenar resultados, copiamos para um `VetorDinamico` e ordenamos ali.

> 🧑‍💻 **Detalhe:** ele tem **move constructor** (`VetorDinamico&&`), o que permite
> retorná-lo de uma função por valor sem cópia cara — por isso as funções de
> `consultas.h` podem fazer `return resultado;`.

---

## 2.6 Gerador de IDs — `gerador_id.h`

### O que é / por que
Gera identificadores únicos automaticamente, para o **usuário nunca digitar um ID**.
Usa uma **pilha** internamente: quando a pilha esvazia, gera um bloco de 8 IDs novos.
Quando um registro é removido, o ID dele pode ser **devolentado** (`liberar`) para reuso.

```cpp
int  obter();            // próximo ID disponível (O(1))
void liberar(int id);    // devolve um ID removido para reuso
void reservar(int id);   // ao carregar do arquivo, evita colidir com IDs existentes
```

> 👶 **Em miúdos:** é uma "senha de atendimento". Cada cadastro pega a próxima senha; se
> alguém cancela, a senha volta para ser reaproveitada.

---

## 2.7 Lista Estática — `lista_estatica.h`

### O que é / por que
Um array de **tamanho fixo** definido em tempo de compilação (`ListaEstatica<T, N>`).
Usada para as **categorias** de veículos (conjunto pequeno e estável). Não precisa de
alocação dinâmica e tem acesso **O(1)**.

```cpp
template <typename T, int CAPACIDADE>
class ListaEstatica {
    T dados[CAPACIDADE];
    int tamanho;
    void inserir(const T&);     // lança overflow_error se cheia
    bool remover(int indice);   // desloca os elementos seguintes
    void limpar();              // zera o tamanho
};
```

No projeto: `ListaEstatica<Categoria, MAX_CATEGORIAS>` com `MAX_CATEGORIAS = 6`.

> ⚙️ **Como modificar:** para permitir mais categorias, aumente `MAX_CATEGORIAS` em
> `servicos/gerenciador_frota.h`. (Esse valor também dimensiona o array de filas de
> espera.)

---

## 2.8 Resumo de complexidade

| Operação | Lista | Hash | Pilha/Fila | Vetor |
|----------|:-----:|:----:|:----------:|:-----:|
| Inserir | O(1) (fim/início) | O(1) médio | O(1) | O(1) amortizado |
| Buscar por chave indexada | O(n) | **O(1) médio** | — | O(1) por índice |
| Remover | O(n) | O(1) médio | O(1) | — |
| Percorrer todos | O(n) | O(n) | O(n) | O(n) |

Continue em → [03 — Algoritmos](03-algoritmos-ordenacao-busca.md)
