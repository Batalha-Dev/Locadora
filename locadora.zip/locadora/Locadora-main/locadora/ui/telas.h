#pragma once
#include "console.h"
#include "tabela.h"
#include "validacao.h"
#include "../servicos/gerenciador_frota.h"
#include "../servicos/gerenciador_clientes.h"
#include "../servicos/gerenciador_locacoes.h"
#include "../servicos/consultas.h"
#include "../servicos/catalogo.h"
#include "../servicos/contrato_pdf.h"
#include "../servicos/persistencia.h"
#include <sstream>
#include <iomanip>
#include <stdexcept>

// ─── Helpers de impressao (tabela estilizada) ────────────────────────────────

// Cria uma grade ja com as colunas padrao de locacao.
inline Tabela::Grade novaGradeLocacoes(const std::string& titulo) {
    Tabela::Grade g(titulo);
    g.colunas({"ID", "CLIENTE", "VEICULO", "INICIO", "PREV.FIM", "VALOR", "STATUS"});
    return g;
}

// Converte uma locacao na linha de celulas correspondente (com cor de status).
inline std::vector<Tabela::Celula> celulasLocacao(const Locacao& l,
                                                  GerenciadorClientes& clientes,
                                                  GerenciadorFrota& frota) {
    Cliente* cli = clientes.buscarPorId(l.idCliente);
    Carro*   car = frota.buscarPorId(l.idCarro);

    std::string nomeCli = cli ? cli->nome : "?";
    std::string nomeVei = car ? (car->marca + " " + car->modelo) : "?";
    if (nomeCli.size() > 18) nomeCli = nomeCli.substr(0, 17) + ".";
    if (nomeVei.size() > 16) nomeVei = nomeVei.substr(0, 15) + ".";

    time_t agora = std::time(nullptr);
    bool emAtraso = (l.status == StatusLocacao::ATIVA && agora > l.dataFimPrevista);

    std::string corStatus = Tabela::COR_TEXTO;
    if (l.status == StatusLocacao::ATIVA)     corStatus = emAtraso ? Cor::VERMELHO : Cor::VERDE;
    if (l.status == StatusLocacao::CANCELADA) corStatus = Cor::CINZA;

    return {
        Tabela::Celula(std::to_string(l.id)),
        Tabela::Celula(nomeCli),
        Tabela::Celula(nomeVei),
        Tabela::Celula(Console::formatarData(l.dataInicio)),
        Tabela::Celula(Console::formatarData(l.dataFimPrevista)),
        Tabela::Celula(Console::formatarMoeda(l.valorTotal), Cor::VERDE),
        Tabela::Celula(emAtraso ? "ATRASO" : l.statusStr(), corStatus)
    };
}

// Dashboards reutilizaveis do catalogo e das categorias (para consultar IDs).
inline Tabela::Grade gradeMarcas(Catalogo& catalogo, const std::string& titulo = "MARCAS") {
    Tabela::Grade g(titulo);
    g.colunas({"ID", "MARCA", "MODELOS"});
    catalogo.getMarcas().paraCada([&](Marca& m) {
        int qtd = catalogo.modelosDaMarca(m.id).getTamanho();
        g.adicionar({
            Tabela::Celula(std::to_string(m.id)),
            Tabela::Celula(m.nome),
            Tabela::Celula(std::to_string(qtd), qtd > 0 ? Cor::VERDE : Cor::CINZA)
        });
    });
    return g;
}

inline Tabela::Grade gradeModelos(Catalogo& catalogo, const std::string& titulo = "MODELOS") {
    Tabela::Grade g(titulo);
    g.colunas({"ID", "MARCA", "MODELO"});
    catalogo.getMarcas().paraCada([&](Marca& m) {
        auto mods = catalogo.modelosDaMarca(m.id);
        for (int i = 0; i < mods.getTamanho(); i++)
            g.adicionar({
                Tabela::Celula(std::to_string(mods[i].id)),
                Tabela::Celula(m.nome),
                Tabela::Celula(mods[i].nome)
            });
    });
    return g;
}

inline Tabela::Grade gradeCategorias(GerenciadorFrota& frota, const std::string& titulo = "CATEGORIAS") {
    Tabela::Grade g(titulo);
    g.colunas({"ID", "CATEGORIA", "DIARIA"});
    auto& cats = frota.getCategorias();
    for (int i = 0; i < cats.getTamanho(); i++)
        g.adicionar({
            Tabela::Celula(std::to_string(cats[i].id)),
            Tabela::Celula(cats[i].nome),
            Tabela::Celula(Console::formatarMoeda(cats[i].diariaPadrao), Cor::VERDE)
        });
    return g;
}

// ─── FROTA ───────────────────────────────────────────────────────────────────

// Monta a tabela (dashboard) da frota completa — reutilizada na listagem da
// frota e no historico por veiculo (para ver os IDs).
inline Tabela::Grade gradeFrota(GerenciadorFrota& frota) {
    Tabela::Grade g("FROTA DE VEICULOS");
    g.colunas({"ID", "PLACA", "MARCA", "MODELO", "ANO", "DIARIA", "CATEGORIA", "STATUS"});
    frota.getFrota().paraCada([&](Carro& c) {
        Categoria* cat = frota.buscarCategoria(c.categoriaId);
        std::string nomeCat = cat ? cat->nome : "?";

        std::string statusCor = Cor::VERDE;
        if (c.status == StatusCarro::LOCADO)     statusCor = Cor::AMARELO;
        if (c.status == StatusCarro::MANUTENCAO) statusCor = Cor::VERMELHO;
        if (c.status == StatusCarro::RESERVADO)  statusCor = Cor::AZUL;

        g.adicionar({
            Tabela::Celula(std::to_string(c.id)),
            Tabela::Celula(c.placa),
            Tabela::Celula(c.marca),
            Tabela::Celula(c.modelo),
            Tabela::Celula(std::to_string(c.ano)),
            Tabela::Celula(Console::formatarMoeda(c.diaria), Cor::VERDE),
            Tabela::Celula(nomeCat),
            Tabela::Celula(c.statusStr(), statusCor)
        });
    });
    return g;
}

inline void telaListarCarros(GerenciadorFrota& frota) {
    Console::limpar();
    if (frota.getFrota().vazia()) {
        Console::cabecalho("FROTA DE VEICULOS");
        Console::aviso("Nenhum veiculo cadastrado.");
        Console::pausar();
        return;
    }
    gradeFrota(frota).desenhar();
    Console::pausar();
}

inline void telaCadastrarCarro(GerenciadorFrota& frota, Catalogo& catalogo) {
    Console::cabecalho("CADASTRAR VEICULO");
    try {
        Console::info("O ID e gerado automaticamente. Digite 0 em qualquer etapa para "
                      "CANCELAR e voltar.");

        // ── 1) MARCA (escolha pela posicao na lista; 0 cancela) ──
        if (catalogo.getMarcas().vazia()) {
            Console::erro("Nenhuma marca no catalogo. Cadastre uma marca primeiro.");
            Console::pausar(); return;
        }
        VetorDinamico<Marca> marcas;
        catalogo.getMarcas().paraCada([&](Marca& m){ marcas.adicionar(m); });

        Marca marca;
        while (true) {
            std::cout << Cor::CIANO << "\n  Marcas:\n" << Cor::RESET;
            for (int i = 0; i < marcas.getTamanho(); i++)
                std::cout << "  [" << (i + 1) << "] " << marcas[i].nome << "\n";
            int op = Console::lerInteiro("Marca ([0] cancela)");
            if (op == 0) return;
            if (op >= 1 && op <= marcas.getTamanho()) { marca = marcas[op - 1]; break; }
            Console::erro("Opcao invalida. Escolha um numero da lista ou 0 para cancelar.");
        }

        // ── 2) MODELO (apenas os da marca; 0 cancela) ──
        auto modelos = catalogo.modelosDaMarca(marca.id);
        if (modelos.vazio()) {
            Console::erro("A marca '" + marca.nome + "' nao possui modelos. "
                          "Cadastre um modelo primeiro.");
            Console::pausar(); return;
        }
        Modelo modelo;
        while (true) {
            std::cout << Cor::CIANO << "\n  Modelos de " << marca.nome << ":\n" << Cor::RESET;
            for (int i = 0; i < modelos.getTamanho(); i++)
                std::cout << "  [" << (i + 1) << "] " << modelos[i].nome << "\n";
            int op = Console::lerInteiro("Modelo ([0] cancela)");
            if (op == 0) return;
            if (op >= 1 && op <= modelos.getTamanho()) { modelo = modelos[op - 1]; break; }
            Console::erro("Opcao invalida. Escolha um numero da lista ou 0 para cancelar.");
        }

        // ── 3) PLACA (digite 0 para cancelar) ──
        std::string placa;
        while (true) {
            std::string ent = Console::lerTexto("Placa (ABC1D23 ou ABC-1234) ([0] cancela)");
            if (ent == "0") return;
            std::string err;
            if (Validacao::validarPlaca(ent, err)) { placa = Validacao::formatarPlaca(ent); break; }
            Console::erro(err);
        }

        // ── 4) ANO (0 cancela; regra centralizada em carro.h) ──
        int anoMin = anoVeiculoMinimo();
        int anoMax = anoVeiculoMaximo();
        Console::info("Ano permitido: " + std::to_string(anoMin) + ", " +
                      std::to_string(anoMax - 1) + " ou " + std::to_string(anoMax) + ".");
        int ano;
        while (true) {
            ano = Console::lerInteiro("Ano ([0] cancela)");
            if (ano == 0) return;
            if (anoVeiculoValido(ano)) break;
            Console::erro("Ano invalido. Informe " + std::to_string(anoMin) + ", " +
                          std::to_string(anoMax - 1) + " ou " + std::to_string(anoMax) + ".");
        }

        // ── 5) CATEGORIA (escolha pela posicao; 0 cancela) ──
        auto& cats = frota.getCategorias();
        if (cats.vazia()) {
            Console::erro("Nenhuma categoria cadastrada. Cadastre uma categoria primeiro.");
            Console::pausar(); return;
        }
        int catId = -1;
        while (true) {
            std::cout << Cor::CIANO << "\n  Categorias:\n" << Cor::RESET;
            for (int i = 0; i < cats.getTamanho(); i++)
                std::cout << "  [" << (i + 1) << "] " << std::left << std::setw(16)
                          << cats[i].nome << Console::formatarMoeda(cats[i].diariaPadrao)
                          << "/dia\n";
            int op = Console::lerInteiro("Categoria ([0] cancela)");
            if (op == 0) return;
            if (op >= 1 && op <= cats.getTamanho()) { catId = cats[op - 1].id; break; }
            Console::erro("Opcao invalida. Escolha um numero da lista ou 0 para cancelar.");
        }

        // ── Efetiva o cadastro ──
        Carro* novo = frota.cadastrar(marca.nome, modelo.nome, placa, ano, catId);
        if (novo)
            Console::sucesso("Veiculo cadastrado! ID automatico: " + std::to_string(novo->id) +
                             " | Placa: " + novo->placa);
        else
            Console::erro("Falha ao cadastrar. A placa pode ja existir.");

        Console::pausar();
    } catch (const std::exception& e) {
        Console::erro(std::string("Erro ao cadastrar veiculo: ") + e.what());
        Console::pausar();
    }
}

inline void telaBuscarVeiculo(GerenciadorFrota& frota) {
    Console::cabecalho("BUSCAR VEICULO");
    if (frota.getFrota().vazia()) {
        Console::aviso("Nenhum veiculo cadastrado."); Console::pausar(); return;
    }
    // Dashboard da frota (para consultar ID e placa).
    gradeFrota(frota).desenhar();
    std::cout << "\n";
    std::cout << "  [1] Por ID\n  [2] Por Placa\n  [0] Voltar\n";

    // Aceita apenas 1 (ID) ou 2 (Placa); 0 volta. Qualquer outro valor e rejeitado.
    int op;
    while (true) {
        op = Console::lerInteiro("Opcao");
        if (op == 0) return;
        if (op == 1 || op == 2) break;
        Console::erro("Opcao invalida. Escolha 1 (ID), 2 (Placa) ou 0 (Voltar).");
    }

    Carro* c = nullptr;
    if (op == 1) {
        int id = Console::lerInteiro("ID do veiculo");
        c = frota.buscarPorId(id);
    } else {
        std::string placa = Console::lerTexto("Placa");
        c = frota.buscarPorPlaca(placa);
    }

    if (!c) { Console::erro("Veiculo nao encontrado."); Console::pausar(); return; }

    Categoria* cat = frota.buscarCategoria(c->categoriaId);

    std::string statusCor = Cor::VERDE;
    if (c->status == StatusCarro::LOCADO)     statusCor = Cor::AMARELO;
    if (c->status == StatusCarro::MANUTENCAO) statusCor = Cor::VERMELHO;
    if (c->status == StatusCarro::RESERVADO)  statusCor = Cor::AZUL;

    std::cout << "\n";
    Tabela::Grade ficha("VEICULO #" + std::to_string(c->id), false);
    ficha.colunas({"CAMPO", "VALOR"});
    ficha.adicionar({Tabela::Celula("Placa"),     Tabela::Celula(c->placa)});
    ficha.adicionar({Tabela::Celula("Marca"),     Tabela::Celula(c->marca)});
    ficha.adicionar({Tabela::Celula("Modelo"),    Tabela::Celula(c->modelo)});
    ficha.adicionar({Tabela::Celula("Ano"),       Tabela::Celula(std::to_string(c->ano))});
    ficha.adicionar({Tabela::Celula("Categoria"), Tabela::Celula(cat ? cat->nome : "?")});
    ficha.adicionar({Tabela::Celula("Diaria"),    Tabela::Celula(Console::formatarMoeda(c->diaria), Cor::VERDE)});
    ficha.adicionar({Tabela::Celula("Status"),    Tabela::Celula(c->statusStr(), statusCor)});
    ficha.desenhar();

    Console::pausar();
}

inline void telaDisponibilidade(GerenciadorFrota& frota) {
    Console::limpar();

    auto& cats = frota.getCategorias();
    Tabela::Grade resumo("DISPONIBILIDADE POR CATEGORIA");
    resumo.colunas({"CATEGORIA", "DISPONIVEIS", "NA FILA"});

    for (int i = 0; i < cats.getTamanho(); i++) {
        int disp = frota.contarDisponiveis(cats[i].id);
        int fila = frota.tamanhoFila(cats[i].id);
        resumo.adicionar({
            Tabela::Celula(cats[i].nome),
            Tabela::Celula(std::to_string(disp), disp > 0 ? Cor::VERDE : Cor::VERMELHO),
            Tabela::Celula(std::to_string(fila), Cor::AMARELO)
        });
    }
    resumo.desenhar();

    auto disponiveis = Consultas::todosDisponiveis(frota);
    if (disponiveis.vazio()) {
        Console::aviso("Nenhum veiculo disponivel no momento.");
    } else {
        std::cout << "\n";
        Tabela::Grade g("VEICULOS DISPONIVEIS");
        g.colunas({"ID", "PLACA", "MARCA", "MODELO", "ANO", "DIARIA"});
        for (int i = 0; i < disponiveis.getTamanho(); i++) {
            Carro& c = disponiveis[i];
            g.adicionar({
                Tabela::Celula(std::to_string(c.id)),
                Tabela::Celula(c.placa),
                Tabela::Celula(c.marca),
                Tabela::Celula(c.modelo),
                Tabela::Celula(std::to_string(c.ano)),
                Tabela::Celula(Console::formatarMoeda(c.diaria), Cor::VERDE)
            });
        }
        g.desenhar();
    }

    Console::pausar();
}

inline void telaManutencao(GerenciadorFrota& frota) {
    Console::cabecalho("MANUTENCAO DE VEICULO");
    if (frota.getFrota().vazia()) {
        Console::aviso("Nenhum veiculo cadastrado."); Console::pausar(); return;
    }
    // Dashboard da frota (para consultar ID e placa).
    gradeFrota(frota).desenhar();
    std::cout << "\n";
    int id = Console::lerInteiro("ID do veiculo");
    Carro* c = frota.buscarPorId(id);

    if (!c) { Console::erro("Veiculo nao encontrado."); Console::pausar(); return; }

    std::cout << "\n  Veiculo: " << c->marca << " " << c->modelo
              << " (" << c->placa << ")\n";

    // Le uma opcao restrita a {1, 0}: 1 confirma a acao, 0 volta.
    auto lerAcao = [&]() -> int {
        while (true) {
            int op = Console::lerInteiro("Opcao");
            if (op == 0 || op == 1) return op;
            Console::erro("Opcao invalida. Escolha 1 ou 0 (Voltar).");
        }
    };

    // A tela so oferece a acao que faz sentido para o status atual.
    if (c->status == StatusCarro::MANUTENCAO) {
        Console::aviso("Este veiculo JA esta em manutencao.");
        std::cout << "\n  [1] Retirar da manutencao (deixar disponivel)\n";
        std::cout << "  [0] Voltar\n";
        if (lerAcao() == 1) {
            frota.marcarDisponivel(id);
            Console::sucesso("Veiculo retirado da manutencao. Agora esta disponivel.");
        }
    }
    else if (c->status == StatusCarro::DISPONIVEL) {
        Console::info("Status atual: disponivel.");
        std::cout << "\n  [1] Enviar para manutencao\n";
        std::cout << "  [0] Voltar\n";
        if (lerAcao() == 1) {
            frota.marcarManutencao(id)
                ? Console::sucesso("Veiculo enviado para manutencao.")
                : Console::erro("Nao foi possivel enviar para manutencao.");
        }
    }
    else {
        // LOCADO ou RESERVADO: nao ha acao de manutencao aplicavel agora.
        Console::aviso("Veiculo esta " + c->statusStr() +
                       ". Nao e possivel alterar a manutencao neste momento.");
        Console::info("Finalize a locacao/reserva antes de enviar para manutencao.");
    }

    Console::pausar();
}

inline void telaCadastrarCategoria(GerenciadorFrota& frota) {
    Console::cabecalho("CADASTRAR CATEGORIA");

    auto& cats = frota.getCategorias();
    if (cats.cheia()) {
        Console::erro("Limite de categorias atingido (" +
                      std::to_string(cats.getCapacidade()) + ").");
        Console::pausar();
        return;
    }

    // Dashboard das categorias existentes (para referencia).
    if (!cats.vazia()) { gradeCategorias(frota).desenhar(); std::cout << "\n"; }

    auto aparar = [](const std::string& s) {
        size_t a = s.find_first_not_of(" \t");
        size_t b = s.find_last_not_of(" \t");
        return (a == std::string::npos) ? std::string() : s.substr(a, b - a + 1);
    };

    // Nome: obrigatorio, sem duplicar, sem ';' (delimitador do CSV).
    std::string nome = aparar(Console::lerTexto("Nome da categoria"));
    if (nome.empty()) { Console::erro("Nome nao pode ser vazio."); Console::pausar(); return; }
    if (nome.find(';') != std::string::npos) {
        Console::erro("Nome nao pode conter ';'."); Console::pausar(); return;
    }
    if (frota.buscarCategoriaPorNome(nome)) {
        Console::erro("Ja existe uma categoria com esse nome."); Console::pausar(); return;
    }

    std::string descricao = aparar(Console::lerTexto("Descricao (opcional)"));
    if (descricao.find(';') != std::string::npos) descricao = "";  // protege o CSV
    if (descricao.empty()) descricao = "-";

    // Diaria: numero > 0. Tratamento de excecao no parse (stod lanca excecao).
    double diaria = 0.0;
    while (true) {
        std::string txt = aparar(Console::lerTexto("Valor da diaria (R$)"));
        for (char& ch : txt) if (ch == ',') ch = '.';   // aceita virgula decimal
        try {
            size_t pos = 0;
            diaria = std::stod(txt, &pos);
            while (pos < txt.size() && std::isspace((unsigned char)txt[pos])) pos++;
            if (pos != txt.size())                       // sobrou lixo (ex.: "120abc")
                throw std::invalid_argument("formato");
            if (diaria <= 0.0) {
                Console::erro("A diaria deve ser maior que zero.");
                continue;
            }
            break;
        } catch (const std::invalid_argument&) {
            Console::erro("Valor invalido. Digite um numero. Ex: 150 ou 150.50");
        } catch (const std::out_of_range&) {
            Console::erro("Valor fora do intervalo permitido.");
        }
    }

    Categoria* nova = frota.adicionarCategoria(nome, descricao, diaria);
    if (nova)
        Console::sucesso("Categoria cadastrada! ID: " + std::to_string(nova->id) +
                         " | Diaria: " + Console::formatarMoeda(nova->diariaPadrao));
    else
        Console::erro("Nao foi possivel cadastrar a categoria.");

    Console::pausar();
}

inline void telaRemoverVeiculo(GerenciadorFrota& frota, GerenciadorLocacoes& locacoes) {
    Console::cabecalho("REMOVER VEICULO");
    if (frota.getFrota().vazia()) {
        Console::aviso("Nenhum veiculo cadastrado."); Console::pausar(); return;
    }
    // Dashboard da frota (para ver os IDs).
    gradeFrota(frota).desenhar();
    std::cout << "\n";

    int id = Console::lerInteiro("ID do veiculo a remover (0 cancela)");
    if (id == 0) return;
    Carro* c = frota.buscarPorId(id);
    if (!c) { Console::erro("Veiculo nao encontrado."); Console::pausar(); return; }

    // Tratamento 1: nao remover veiculo locado.
    if (c->status == StatusCarro::LOCADO) {
        Console::erro("Veiculo esta LOCADO. Registre a devolucao antes de remover.");
        Console::pausar(); return;
    }

    // Tratamento 2: verifica locacao ativa / historico do veiculo.
    bool temAtiva = false, temHistorico = false;
    locacoes.getLocacoes().paraCada([&](Locacao& l) {
        if (l.idCarro == id) {
            temHistorico = true;
            if (l.status == StatusLocacao::ATIVA) temAtiva = true;
        }
    });
    if (temAtiva) {
        Console::erro("Veiculo possui locacao ativa. Nao e possivel remover.");
        Console::pausar(); return;
    }

    // Ficha do veiculo + confirmacao (mesmo estilo das outras telas).
    Categoria* cat = frota.buscarCategoria(c->categoriaId);
    std::string statusCor = Cor::VERDE;
    if (c->status == StatusCarro::MANUTENCAO) statusCor = Cor::VERMELHO;
    if (c->status == StatusCarro::RESERVADO)  statusCor = Cor::AZUL;

    std::cout << "\n";
    Tabela::Grade ficha("VEICULO #" + std::to_string(c->id), false);
    ficha.colunas({"CAMPO", "VALOR"});
    ficha.adicionar({Tabela::Celula("Placa"),     Tabela::Celula(c->placa)});
    ficha.adicionar({Tabela::Celula("Marca"),     Tabela::Celula(c->marca)});
    ficha.adicionar({Tabela::Celula("Modelo"),    Tabela::Celula(c->modelo)});
    ficha.adicionar({Tabela::Celula("Ano"),       Tabela::Celula(std::to_string(c->ano))});
    ficha.adicionar({Tabela::Celula("Categoria"), Tabela::Celula(cat ? cat->nome : "?")});
    ficha.adicionar({Tabela::Celula("Diaria"),    Tabela::Celula(Console::formatarMoeda(c->diaria), Cor::VERDE)});
    ficha.adicionar({Tabela::Celula("Status"),    Tabela::Celula(c->statusStr(), statusCor)});
    ficha.desenhar();

    if (temHistorico)
        Console::info("Este veiculo possui historico de locacoes (sera preservado).");
    Console::aviso("Esta acao nao pode ser desfeita.");

    if (Console::lerInteiro("Confirmar remocao? [1=Sim / 0=Nao]") == 1) {
        // Se houver historico, NAO reutiliza o ID (preserva a integridade do historico).
        frota.remover(id, !temHistorico)
            ? Console::sucesso("Veiculo removido com sucesso.")
            : Console::erro("Falha ao remover veiculo.");
    } else {
        Console::aviso("Operacao cancelada.");
    }
    Console::pausar();
}

inline void telaRemoverCategoria(GerenciadorFrota& frota) {
    Console::cabecalho("REMOVER CATEGORIA");
    auto& cats = frota.getCategorias();
    if (cats.vazia()) {
        Console::aviso("Nenhuma categoria cadastrada."); Console::pausar(); return;
    }
    gradeCategorias(frota).desenhar();
    std::cout << "\n";

    // Obs.: categorias usam id a partir de 0, por isso o cancelamento e -1.
    int id = Console::lerInteiro("ID da categoria a remover (-1 cancela)");
    if (id < 0) return;
    Categoria* cat = frota.buscarCategoria(id);
    if (!cat) { Console::erro("Categoria nao encontrada."); Console::pausar(); return; }
    std::string nome = cat->nome;

    // Tratamento: nao remover categoria com veiculos vinculados.
    int qtdCarros = frota.contarVeiculosNaCategoria(id);
    if (qtdCarros > 0) {
        Console::erro("Existem " + std::to_string(qtdCarros) +
                      " veiculo(s) nesta categoria. Reclassifique-os antes de remover.");
        Console::pausar(); return;
    }

    Console::aviso("Remover a categoria '" + nome + "'? Acao irreversivel.");
    if (Console::lerInteiro("Confirmar? [1=Sim / 0=Nao]") == 1)
        frota.removerCategoria(id) ? Console::sucesso("Categoria removida.")
                                   : Console::erro("Falha ao remover categoria.");
    else
        Console::aviso("Operacao cancelada.");
    Console::pausar();
}

// ─── CATALOGO (marcas / modelos) ──────────────────────────────────────────────

inline void telaListarCatalogo(Catalogo& catalogo) {
    Console::limpar();

    if (catalogo.getMarcas().vazia()) {
        Console::cabecalho("CATALOGO");
        Console::aviso("Catalogo vazio. Cadastre uma marca.");
        Console::pausar();
        return;
    }

    // Tabela de marcas (com a quantidade de modelos de cada uma).
    Tabela::Grade gm("CATALOGO - MARCAS");
    gm.colunas({"ID", "MARCA", "MODELOS"});
    catalogo.getMarcas().paraCada([&](Marca& m){
        int qtd = catalogo.modelosDaMarca(m.id).getTamanho();
        gm.adicionar({
            Tabela::Celula(std::to_string(m.id)),
            Tabela::Celula(m.nome),
            Tabela::Celula(std::to_string(qtd), qtd > 0 ? Cor::VERDE : Cor::CINZA)
        });
    });
    gm.desenhar();
    std::cout << "\n";

    // Tabela de modelos, agrupados por marca.
    Tabela::Grade gmod("CATALOGO - MODELOS");
    gmod.colunas({"ID", "MARCA", "MODELO"});
    catalogo.getMarcas().paraCada([&](Marca& m){
        auto mods = catalogo.modelosDaMarca(m.id);
        for (int i = 0; i < mods.getTamanho(); i++)
            gmod.adicionar({
                Tabela::Celula(std::to_string(mods[i].id)),
                Tabela::Celula(m.nome),
                Tabela::Celula(mods[i].nome)
            });
    });
    if (!gmod.vazia()) gmod.desenhar();

    Console::info("Marcas: " + std::to_string(catalogo.totalMarcas()) +
                  " | Modelos: " + std::to_string(catalogo.totalModelos()));
    Console::pausar();
}

inline void telaCadastrarMarca(Catalogo& catalogo) {
    Console::cabecalho("CADASTRAR MARCA");
    // Dashboard das marcas ja existentes (para nao duplicar).
    if (!catalogo.getMarcas().vazia()) { gradeMarcas(catalogo).desenhar(); std::cout << "\n"; }
    std::string nome = Console::lerTexto("Nome da marca");
    if (nome.empty()) { Console::erro("Nome vazio."); Console::pausar(); return; }

    Marca* m = catalogo.adicionarMarca(nome);
    if (m) Console::sucesso("Marca cadastrada! ID automatico: " + std::to_string(m->id));
    else   Console::erro("Marca ja existe ou nome invalido.");
    Console::pausar();
}

inline void telaCadastrarModelo(Catalogo& catalogo) {
    Console::cabecalho("CADASTRAR MODELO");

    if (catalogo.getMarcas().vazia()) {
        Console::erro("Cadastre uma marca antes.");
        Console::pausar();
        return;
    }
    // Dashboard das marcas (para escolher o ID) e dos modelos ja existentes.
    gradeMarcas(catalogo).desenhar();
    if (!gradeModelos(catalogo).vazia()) { std::cout << "\n"; gradeModelos(catalogo).desenhar(); }
    std::cout << "\n";
    int marcaId  = Console::lerInteiro("Marca (ID)");
    Marca* marca = catalogo.buscarMarca(marcaId);
    if (!marca) { Console::erro("Marca invalida."); Console::pausar(); return; }

    std::string nome = Console::lerTexto("Nome do modelo");
    if (nome.empty()) { Console::erro("Nome vazio."); Console::pausar(); return; }

    Modelo* mod = catalogo.adicionarModelo(marcaId, nome);
    if (mod) Console::sucesso("Modelo cadastrado em " + marca->nome +
                              "! ID automatico: " + std::to_string(mod->id));
    else     Console::erro("Modelo ja existe nessa marca ou dados invalidos.");
    Console::pausar();
}

inline void telaRemoverMarca(Catalogo& catalogo, GerenciadorFrota& frota) {
    Console::cabecalho("REMOVER MARCA");
    if (catalogo.getMarcas().vazia()) {
        Console::aviso("Nenhuma marca cadastrada."); Console::pausar(); return;
    }
    gradeMarcas(catalogo).desenhar();
    std::cout << "\n";

    int id = Console::lerInteiro("ID da marca a remover (0 cancela)");
    if (id == 0) return;
    Marca* m = catalogo.buscarMarca(id);
    if (!m) { Console::erro("Marca nao encontrada."); Console::pausar(); return; }
    std::string nomeMarca = m->nome;

    // Tratamento 1: nao remover marca que ainda tem modelos vinculados.
    int qtdModelos = catalogo.contarModelosDaMarca(id);
    if (qtdModelos > 0) {
        Console::erro("Marca possui " + std::to_string(qtdModelos) +
                      " modelo(s). Remova os modelos desta marca primeiro.");
        Console::pausar(); return;
    }
    // Tratamento 2: nao remover marca usada por veiculos da frota.
    int qtdCarros = 0;
    frota.getFrota().paraCada([&](Carro& c){ if (c.marca == nomeMarca) qtdCarros++; });
    if (qtdCarros > 0) {
        Console::erro("Existem " + std::to_string(qtdCarros) +
                      " veiculo(s) desta marca na frota. Nao e possivel remover.");
        Console::pausar(); return;
    }

    Console::aviso("Remover a marca '" + nomeMarca + "'? Acao irreversivel.");
    if (Console::lerInteiro("Confirmar? [1=Sim / 0=Nao]") == 1)
        catalogo.removerMarca(id) ? Console::sucesso("Marca removida.")
                                  : Console::erro("Falha ao remover marca.");
    else
        Console::aviso("Operacao cancelada.");
    Console::pausar();
}

inline void telaRemoverModelo(Catalogo& catalogo, GerenciadorFrota& frota) {
    Console::cabecalho("REMOVER MODELO");
    if (catalogo.getMarcas().vazia()) {
        Console::aviso("Nenhuma marca/modelo cadastrado."); Console::pausar(); return;
    }
    gradeMarcas(catalogo).desenhar();
    std::cout << "\n";
    int marcaId = Console::lerInteiro("ID da marca (0 cancela)");
    if (marcaId == 0) return;
    Marca* marca = catalogo.buscarMarca(marcaId);
    if (!marca) { Console::erro("Marca invalida."); Console::pausar(); return; }

    auto mods = catalogo.modelosDaMarca(marcaId);
    if (mods.vazio()) {
        Console::aviso("Esta marca nao possui modelos."); Console::pausar(); return;
    }
    std::cout << "\n";
    Tabela::Grade gmod("MODELOS DE " + marca->nome);
    gmod.colunas({"ID", "MODELO"});
    for (int i = 0; i < mods.getTamanho(); i++)
        gmod.adicionar({Tabela::Celula(std::to_string(mods[i].id)), Tabela::Celula(mods[i].nome)});
    gmod.desenhar();
    std::cout << "\n";

    int modeloId = Console::lerInteiro("ID do modelo a remover (0 cancela)");
    if (modeloId == 0) return;
    Modelo* mod = catalogo.buscarModelo(modeloId);
    if (!mod || mod->marcaId != marcaId) {
        Console::erro("Modelo invalido para a marca escolhida."); Console::pausar(); return;
    }
    std::string nomeMarca = marca->nome, nomeModelo = mod->nome;

    // Tratamento: nao remover modelo usado por veiculos da frota.
    int qtdCarros = 0;
    frota.getFrota().paraCada([&](Carro& c){
        if (c.marca == nomeMarca && c.modelo == nomeModelo) qtdCarros++;
    });
    if (qtdCarros > 0) {
        Console::erro("Existem " + std::to_string(qtdCarros) +
                      " veiculo(s) deste modelo na frota. Nao e possivel remover.");
        Console::pausar(); return;
    }

    Console::aviso("Remover o modelo '" + nomeModelo + "' (" + nomeMarca + ")?");
    if (Console::lerInteiro("Confirmar? [1=Sim / 0=Nao]") == 1)
        catalogo.removerModelo(modeloId) ? Console::sucesso("Modelo removido.")
                                         : Console::erro("Falha ao remover modelo.");
    else
        Console::aviso("Operacao cancelada.");
    Console::pausar();
}

// ─── CLIENTES ─────────────────────────────────────────────────────────────────

// Ficha do cliente no estilo emoldurado (mesmo visual do dashboard).
inline Tabela::Grade fichaCliente(const Cliente& c) {
    Tabela::Grade g("CLIENTE #" + std::to_string(c.id), false);
    g.colunas({"CAMPO", "VALOR"});
    g.adicionar({Tabela::Celula("Nome"),     Tabela::Celula(c.nome)});
    g.adicionar({Tabela::Celula("CPF"),      Tabela::Celula(c.cpf)});
    g.adicionar({Tabela::Celula("Telefone"), Tabela::Celula(c.telefone)});
    g.adicionar({Tabela::Celula("Email"),    Tabela::Celula(c.email)});
    return g;
}

// Monta a tabela (dashboard) de clientes — reutilizada na listagem e na locacao.
inline Tabela::Grade gradeClientes(GerenciadorClientes& clientes) {
    Tabela::Grade g("CLIENTES CADASTRADOS");
    g.colunas({"ID", "NOME", "CPF", "TELEFONE", "EMAIL"});
    g.larguraMinima(1, 40);   // NOME larga; ainda cresce p/ nomes grandes
    clientes.getClientes().paraCada([&](Cliente& c) {
        g.adicionar({
            Tabela::Celula(std::to_string(c.id)),
            Tabela::Celula(c.nome),
            Tabela::Celula(c.cpf),
            Tabela::Celula(c.telefone),
            Tabela::Celula(c.email)
        });
    });
    return g;
}

inline void telaListarClientes(GerenciadorClientes& clientes) {
    Console::limpar();

    if (clientes.getClientes().vazia()) {
        Console::cabecalho("CLIENTES CADASTRADOS");
        Console::aviso("Nenhum cliente cadastrado.");
        Console::pausar();
        return;
    }

    gradeClientes(clientes).desenhar();
    Console::pausar();
}

inline void telaCadastrarCliente(GerenciadorClientes& clientes) {
    Console::cabecalho("CADASTRAR CLIENTE");

    // Nome e sobrenome em campos separados. Cada parte aceita letras (com
    // acentos de qualquer idioma), espaco, hifen e apostrofo - sem numeros/simbolos.
    std::string nome = Console::lerTextoValidado(
        "Nome",
        [](const std::string& v, std::string& e){ return Validacao::validarNomeParte(v, "Nome", e); }
    );
    if (nome.empty()) return;   // EOF

    std::string sobrenome = Console::lerTextoValidado(
        "Sobrenome",
        [](const std::string& v, std::string& e){ return Validacao::validarNomeParte(v, "Sobrenome", e); }
    );
    if (sobrenome.empty()) return;

    auto aparar = [](const std::string& s) {
        size_t a = s.find_first_not_of(" \t");
        size_t b = s.find_last_not_of(" \t");
        return (a == std::string::npos) ? std::string() : s.substr(a, b - a + 1);
    };
    std::string nomeCompleto = aparar(nome) + " " + aparar(sobrenome);

    std::string cpf = Console::lerTextoValidado(
        "CPF (somente numeros ou 000.000.000-00)",
        [](const std::string& v, std::string& e){ return Validacao::validarCpf(v, e); }
    );
    cpf = Validacao::formatarCpf(cpf);

    std::string telefone = Console::lerTextoValidado(
        "Telefone (somente numeros ou (DD) 9XXXX-XXXX)",
        [](const std::string& v, std::string& e){ return Validacao::validarTelefone(v, e); }
    );
    telefone = Validacao::formatarTelefone(telefone);

    std::string email = Console::lerTextoValidado(
        "Email (ex: nome@dominio.com)",
        [](const std::string& v, std::string& e){ return Validacao::validarEmail(v, e); }
    );

    Cliente* novo = clientes.cadastrar(nomeCompleto, cpf, telefone, email);
    if (novo)
        Console::sucesso("Cliente cadastrado! ID: " + std::to_string(novo->id));
    else
        Console::erro("CPF ja cadastrado no sistema.");

    Console::pausar();
}

inline void telaBuscarCliente(GerenciadorClientes& clientes) {
    Console::cabecalho("BUSCAR CLIENTE");
    std::cout << "  [1] Por ID\n  [2] Por CPF\n  [0] Voltar\n";

    // Aceita apenas 1 (ID) ou 2 (CPF); 0 volta. Qualquer outro valor e rejeitado.
    int op;
    while (true) {
        op = Console::lerInteiro("Opcao");
        if (op == 0) return;
        if (op == 1 || op == 2) break;
        Console::erro("Opcao invalida. Escolha 1 (ID), 2 (CPF) ou 0 (Voltar).");
    }

    Cliente* c = nullptr;
    if (op == 1) {
        int id = Console::lerInteiro("ID do cliente");
        c = clientes.buscarPorId(id);
    } else {
        std::string cpf = Console::lerTexto("CPF");
        cpf = Validacao::formatarCpf(cpf);
        c = clientes.buscarPorCpf(cpf);
    }

    if (!c) { Console::erro("Cliente nao encontrado."); Console::pausar(); return; }

    std::cout << "\n";
    fichaCliente(*c).desenhar();

    Console::pausar();
}

inline void telaRemoverCliente(GerenciadorClientes& clientes,
                                GerenciadorLocacoes& locacoes) {
    Console::cabecalho("REMOVER CLIENTE");

    int id = Console::lerInteiro("ID do cliente a remover");
    Cliente* c = clientes.buscarPorId(id);

    if (!c) {
        Console::erro("Cliente nao encontrado.");
        Console::pausar();
        return;
    }

    // Impede remocao se o cliente tiver locacao ativa.
    // temHistorico controla se o id pode ser reaproveitado (so se nao houver
    // nenhuma locacao apontando para ele, para nao corromper o historico).
    bool temAtiva = false, temHistorico = false;
    locacoes.getLocacoes().paraCada([&](Locacao& l) {
        if (l.idCliente == id) {
            temHistorico = true;
            if (l.status == StatusLocacao::ATIVA) temAtiva = true;
        }
    });

    if (temAtiva) {
        Console::erro("Nao e possivel remover: cliente possui locacao ativa.");
        Console::pausar();
        return;
    }

    std::cout << "\n";
    fichaCliente(*c).desenhar();
    Console::aviso("Esta acao nao pode ser desfeita.");

    int confirmar = Console::lerInteiro("Confirmar remocao? [1=Sim / 0=Nao]");
    if (confirmar == 1) {
        clientes.remover(id, !temHistorico)
            ? Console::sucesso("Cliente removido com sucesso.")
            : Console::erro("Falha ao remover cliente.");
    } else {
        Console::aviso("Operacao cancelada.");
    }

    Console::pausar();
}

// ─── LOCACOES ─────────────────────────────────────────────────────────────────

inline void telaListarLocacoes(GerenciadorLocacoes& locacoes,
                               GerenciadorClientes& clientes,
                               GerenciadorFrota& frota) {
    Console::limpar();

    if (locacoes.getLocacoes().vazia()) {
        Console::cabecalho("TODAS AS LOCACOES");
        Console::aviso("Nenhuma locacao registrada.");
        Console::pausar();
        return;
    }

    Tabela::Grade g = novaGradeLocacoes("TODAS AS LOCACOES");
    locacoes.getLocacoes().paraCada([&](Locacao& l) {
        g.adicionar(celulasLocacao(l, clientes, frota));
    });

    g.desenhar();
    Console::pausar();
}

inline void telaLocacoesAtivas(GerenciadorLocacoes& locacoes,
                               GerenciadorClientes& clientes,
                               GerenciadorFrota& frota) {
    Console::limpar();

    auto ativas = Consultas::locacoesAtivasOrdenadas(locacoes);
    if (ativas.vazio()) {
        Console::cabecalho("LOCACOES ATIVAS");
        Console::aviso("Nenhuma locacao ativa.");
        Console::pausar();
        return;
    }

    Tabela::Grade g = novaGradeLocacoes("LOCACOES ATIVAS (ordenadas por data de inicio)");
    for (int i = 0; i < ativas.getTamanho(); i++)
        g.adicionar(celulasLocacao(ativas[i], clientes, frota));

    g.desenhar();
    Console::info("Vermelho = em atraso");
    Console::pausar();
}

inline void telaLocacoesEmAtraso(GerenciadorLocacoes& locacoes,
                                  GerenciadorClientes& clientes,
                                  GerenciadorFrota& frota) {
    Console::limpar();

    auto atrasadas = Consultas::locacoesEmAtraso(locacoes);
    if (atrasadas.vazio()) {
        Console::cabecalho("LOCACOES EM ATRASO");
        Console::sucesso("Nenhuma locacao em atraso.");
        Console::pausar();
        return;
    }

    Tabela::Grade g = novaGradeLocacoes("LOCACOES EM ATRASO");
    for (int i = 0; i < atrasadas.getTamanho(); i++)
        g.adicionar(celulasLocacao(atrasadas[i], clientes, frota));

    g.desenhar();
    Console::pausar();
}

// Tabela (dashboard) de veiculos disponiveis — usada na locacao para ver os IDs.
inline Tabela::Grade gradeVeiculosDisponiveis(GerenciadorFrota& frota) {
    Tabela::Grade g("VEICULOS DISPONIVEIS");
    g.colunas({"ID", "PLACA", "MARCA", "MODELO", "ANO", "DIARIA"});
    auto disp = Consultas::todosDisponiveis(frota);
    for (int i = 0; i < disp.getTamanho(); i++) {
        Carro& c = disp[i];
        g.adicionar({
            Tabela::Celula(std::to_string(c.id)),
            Tabela::Celula(c.placa),
            Tabela::Celula(c.marca),
            Tabela::Celula(c.modelo),
            Tabela::Celula(std::to_string(c.ano)),
            Tabela::Celula(Console::formatarMoeda(c.diaria), Cor::VERDE)
        });
    }
    return g;
}

inline void telaNovaLocacao(GerenciadorLocacoes& locacoes,
                            GerenciadorClientes& clientes,
                            GerenciadorFrota& frota) {
    Console::cabecalho("NOVA LOCACAO");
    try {
        if (clientes.getClientes().vazia()) {
            Console::erro("Nenhum cliente cadastrado. Cadastre um cliente primeiro.");
            Console::pausar(); return;
        }

        // 1) Dashboard de CLIENTES (para escolher o ID).
        gradeClientes(clientes).desenhar();
        std::cout << "\n";

        int idCliente; Cliente* cli = nullptr;
        while (true) {
            idCliente = Console::lerInteiro("ID do cliente (0 cancela)");
            if (idCliente == 0) return;
            cli = clientes.buscarPorId(idCliente);
            if (cli) break;
            Console::erro("Cliente nao encontrado. Tente novamente.");
        }
        Console::info("Cliente: " + cli->nome + " | CPF: " + cli->cpf);

        // 2) Dashboard de VEICULOS DISPONIVEIS (para escolher o ID).
        if (Consultas::todosDisponiveis(frota).vazio()) {
            Console::aviso("Nenhum veiculo disponivel no momento.");
            Console::pausar(); return;
        }
        std::cout << "\n";
        gradeVeiculosDisponiveis(frota).desenhar();
        std::cout << "\n";

        int idCarro; Carro* car = nullptr;
        while (true) {
            idCarro = Console::lerInteiro("ID do veiculo (0 cancela)");
            if (idCarro == 0) return;
            car = frota.buscarPorId(idCarro);
            if (!car) { Console::erro("Veiculo nao encontrado. Tente novamente."); continue; }
            if (car->status != StatusCarro::DISPONIVEL) {
                Console::aviso("Veiculo nao disponivel (" + car->statusStr() + ").");
                int entrar = Console::lerInteiro("Entrar na fila de espera dessa categoria? [1=Sim / 0=Nao]");
                if (entrar == 1) {
                    frota.entrarFilaEspera(idCliente, car->categoriaId);
                    Console::sucesso("Cliente adicionado a fila de espera.");
                }
                Console::pausar(); return;
            }
            break;
        }
        Console::info("Veiculo: " + car->marca + " " + car->modelo +
                      " | Placa: " + car->placa +
                      " | " + Console::formatarMoeda(car->diaria) + "/dia");

        // 3) Quantidade de dias (numero positivo).
        int dias;
        while (true) {
            dias = Console::lerInteiro("Quantidade de dias (0 cancela)");
            if (dias == 0) return;
            if (dias > 0) break;
            Console::erro("Numero de dias invalido (use um valor positivo).");
        }

        double valorEst  = dias * car->diaria;
        time_t agora     = std::time(nullptr);
        time_t devolPrev = agora + dias * 86400;

        std::cout << "\n";
        Console::linha();
        std::cout << "  Retirada prevista : " << Console::formatarData(agora)     << "\n";
        std::cout << "  Devolucao prevista: " << Console::formatarData(devolPrev) << "\n";
        std::cout << "  Valor estimado    : " << Cor::VERDE
                  << Console::formatarMoeda(valorEst) << Cor::RESET << "\n";
        Console::linha();

        if (Console::lerInteiro("Confirmar locacao? [1=Sim / 0=Nao]") == 1) {
            Locacao* loc = locacoes.registrarLocacao(idCliente, idCarro, dias);
            if (loc) {
                Console::sucesso("Locacao #" + std::to_string(loc->id) + " registrada.");
                // Gera o contrato juridico em PDF na pasta 'juridico/'.
                Categoria* cat = frota.buscarCategoria(car->categoriaId);
                std::string pdf = Contrato::gerarContratoLocacao(
                    *loc, *cli, *car, cat ? cat->nome : "-", dias);
                if (!pdf.empty()) Console::info("Contrato gerado: " + pdf);
                else              Console::aviso("Nao foi possivel gerar o contrato em PDF.");
            } else {
                Console::erro("Falha. Cliente pode ja ter uma locacao ativa.");
            }
        } else {
            Console::aviso("Operacao cancelada.");
        }
        Console::pausar();
    } catch (const std::exception& e) {
        Console::erro(std::string("Erro ao processar a locacao: ") + e.what());
        Console::pausar();
    }
}

inline void telaDevolucao(GerenciadorLocacoes& locacoes,
                          GerenciadorClientes& clientes,
                          GerenciadorFrota& frota) {
    Console::cabecalho("REGISTRAR DEVOLUCAO");
    try {
        auto ativas = Consultas::locacoesAtivasOrdenadas(locacoes);
        if (ativas.vazio()) {
            Console::aviso("Nenhuma locacao ativa para devolver.");
            Console::pausar(); return;
        }

        // Dashboard das LOCACOES ATIVAS (para escolher o ID).
        Tabela::Grade g = novaGradeLocacoes("LOCACOES ATIVAS");
        for (int i = 0; i < ativas.getTamanho(); i++)
            g.adicionar(celulasLocacao(ativas[i], clientes, frota));
        g.desenhar();
        std::cout << "\n";

        Locacao* loc = nullptr;
        while (true) {
            int id = Console::lerInteiro("ID da locacao a devolver (0 cancela)");
            if (id == 0) return;
            loc = locacoes.buscarPorId(id);
            if (!loc) { Console::erro("Locacao nao encontrada. Tente novamente."); continue; }
            if (loc->status != StatusLocacao::ATIVA) {
                Console::erro("Locacao nao esta ativa (status: " + loc->statusStr() + ").");
                continue;
            }
            break;
        }

        Cliente* cli = clientes.buscarPorId(loc->idCliente);
        Carro*   car = frota.buscarPorId(loc->idCarro);
        time_t agora = std::time(nullptr);
        int diasReais = loc->diasCobrados(agora);
        double valorFinal = car ? loc->valorCobrado(car->diaria, agora) : loc->valorTotal;

        std::cout << "\n";
        Console::linha();
        if (cli) std::cout << "  Cliente   : " << cli->nome << "\n";
        if (car) std::cout << "  Veiculo   : " << car->marca << " " << car->modelo
                           << " (" << car->placa << ")\n";
        std::cout << "  Inicio    : " << Console::formatarData(loc->dataInicio)      << "\n";
        std::cout << "  Prev. fim : " << Console::formatarData(loc->dataFimPrevista) << "\n";
        std::cout << "  Dias reais: " << diasReais << "\n";
        if (agora > loc->dataFimPrevista)
            std::cout << Cor::VERMELHO << "  ATENCAO: devolucao em atraso!\n" << Cor::RESET;
        std::cout << "  Valor final: " << Cor::VERDE
                  << Console::formatarMoeda(valorFinal) << Cor::RESET << "\n";
        Console::linha();

        if (Console::lerInteiro("Confirmar devolucao? [1=Sim / 0=Nao]") == 1) {
            locacoes.registrarDevolucao(loc->id)
                ? Console::sucesso("Devolucao registrada com sucesso.")
                : Console::erro("Erro ao registrar devolucao.");
        } else {
            Console::aviso("Operacao cancelada.");
        }
        Console::pausar();
    } catch (const std::exception& e) {
        Console::erro(std::string("Erro ao processar a devolucao: ") + e.what());
        Console::pausar();
    }
}

inline void telaRenovacao(GerenciadorLocacoes& locacoes,
                          GerenciadorClientes& clientes,
                          GerenciadorFrota& frota) {
    Console::cabecalho("RENOVACAO DE DIARIAS");
    try {
        auto ativas = Consultas::locacoesAtivasOrdenadas(locacoes);
        if (ativas.vazio()) {
            Console::aviso("Nenhuma locacao ativa para renovar.");
            Console::pausar(); return;
        }

        // Dashboard das LOCACOES ATIVAS (para escolher o ID).
        Tabela::Grade g = novaGradeLocacoes("LOCACOES ATIVAS");
        for (int i = 0; i < ativas.getTamanho(); i++)
            g.adicionar(celulasLocacao(ativas[i], clientes, frota));
        g.desenhar();
        std::cout << "\n";

        Locacao* loc = nullptr;
        while (true) {
            int id = Console::lerInteiro("ID da locacao a renovar (0 cancela)");
            if (id == 0) return;
            loc = locacoes.buscarPorId(id);
            if (!loc) { Console::erro("Locacao nao encontrada. Tente novamente."); continue; }
            if (loc->status != StatusLocacao::ATIVA) {
                Console::erro("Locacao nao esta ativa (status: " + loc->statusStr() + ").");
                continue;
            }
            break;
        }

        Cliente* cli = clientes.buscarPorId(loc->idCliente);
        Carro*   car = frota.buscarPorId(loc->idCarro);
        Console::info(std::string("Cliente: ") + (cli ? cli->nome : "?") +
                      " | Veiculo: " + (car ? car->marca + " " + car->modelo : "?"));
        std::cout << "  Devolucao prevista atual : " << Console::formatarData(loc->dataFimPrevista) << "\n";
        std::cout << "  Valor atual              : " << Console::formatarMoeda(loc->valorTotal) << "\n\n";

        int diasAdic;
        while (true) {
            diasAdic = Console::lerInteiro("Diarias a adicionar (0 cancela)");
            if (diasAdic == 0) return;
            if (diasAdic > 0) break;
            Console::erro("Numero de diarias invalido (use um valor positivo).");
        }

        double diaria    = car ? car->diaria : 0.0;
        double acrescimo = diasAdic * diaria;
        time_t novaPrev  = loc->dataFimPrevista + (time_t)diasAdic * 86400;

        std::cout << "\n";
        Console::linha();
        std::cout << "  Diarias adicionais : " << diasAdic << "\n";
        std::cout << "  Acrescimo          : " << Cor::AMARELO
                  << Console::formatarMoeda(acrescimo) << Cor::RESET << "\n";
        std::cout << "  Nova devolucao     : " << Console::formatarData(novaPrev) << "\n";
        std::cout << "  Novo valor total   : " << Cor::VERDE
                  << Console::formatarMoeda(loc->valorTotal + acrescimo) << Cor::RESET << "\n";
        Console::linha();

        if (Console::lerInteiro("Confirmar renovacao? [1=Sim / 0=Nao]") == 1) {
            if (locacoes.renovarLocacao(loc->id, diasAdic)) {
                Console::sucesso("Locacao #" + std::to_string(loc->id) + " renovada (+" +
                                 std::to_string(diasAdic) + " diaria(s)).");
                // Gera um TERMO ADITIVO separado (preserva o contrato original).
                if (car && cli) {
                    Categoria* cat = frota.buscarCategoria(car->categoriaId);
                    std::string pdf = Contrato::gerarTermoAditivo(
                        *loc, *cli, *car, cat ? cat->nome : "-", diasAdic);
                    if (!pdf.empty()) Console::info("Termo aditivo gerado: " + pdf);
                }
            } else {
                Console::erro("Falha ao renovar a locacao.");
            }
        } else {
            Console::aviso("Operacao cancelada.");
        }
        Console::pausar();
    } catch (const std::exception& e) {
        Console::erro(std::string("Erro ao renovar: ") + e.what());
        Console::pausar();
    }
}

inline void telaRegistrarAtraso(GerenciadorLocacoes& locacoes,
                                GerenciadorClientes& clientes,
                                GerenciadorFrota& frota) {
    Console::cabecalho("REGISTRAR ATRASO / MULTA");
    try {
        auto atrasadas = Consultas::locacoesEmAtraso(locacoes);
        if (atrasadas.vazio()) {
            Console::sucesso("Nenhuma locacao em atraso no momento.");
            Console::pausar(); return;
        }

        // Dashboard das LOCACOES EM ATRASO (para escolher o ID).
        Tabela::Grade g = novaGradeLocacoes("LOCACOES EM ATRASO");
        for (int i = 0; i < atrasadas.getTamanho(); i++)
            g.adicionar(celulasLocacao(atrasadas[i], clientes, frota));
        g.desenhar();
        std::cout << "\n";

        Locacao* loc = nullptr;
        while (true) {
            int id = Console::lerInteiro("ID da locacao em atraso (0 cancela)");
            if (id == 0) return;
            loc = locacoes.buscarPorId(id);
            if (!loc) { Console::erro("Locacao nao encontrada. Tente novamente."); continue; }
            if (loc->status != StatusLocacao::ATIVA) {
                Console::erro("Locacao nao esta ativa."); continue;
            }
            if (loc->diasAtraso(std::time(nullptr)) <= 0) {
                Console::erro("Esta locacao NAO esta em atraso."); continue;
            }
            break;
        }

        FechamentoAtraso f = locacoes.calcularAtraso(loc->id);
        Cliente* cli = clientes.buscarPorId(loc->idCliente);
        Carro*   car = frota.buscarPorId(loc->idCarro);

        // Dashboard com os dados do atraso (cliente, veiculo, valores e multa).
        Tabela::Grade d("DADOS DO ATRASO", false);
        d.colunas({"CAMPO", "VALOR"});
        d.larguraMinima(1, 28);
        d.adicionar({Tabela::Celula("Cliente"),         Tabela::Celula(cli ? cli->nome : "?")});
        d.adicionar({Tabela::Celula("CPF"),             Tabela::Celula(cli ? cli->cpf : "-")});
        d.adicionar({Tabela::Celula("Veiculo"),         Tabela::Celula(car ? car->marca + " " + car->modelo + " (" + car->placa + ")" : "?")});
        d.adicionar({Tabela::Celula("Devolucao prevista"), Tabela::Celula(Console::formatarData(loc->dataFimPrevista))});
        d.adicionar({Tabela::Celula("Dias em atraso"),  Tabela::Celula(std::to_string(f.diasAtraso), Cor::VERMELHO)});
        d.adicionar({Tabela::Celula("Valor das diarias"), Tabela::Celula(Console::formatarMoeda(f.valorDiarias))});
        d.adicionar({Tabela::Celula("Multa do atraso"), Tabela::Celula(Console::formatarMoeda(f.multa), Cor::VERMELHO)});
        d.adicionar({Tabela::Celula("TOTAL a pagar"),   Tabela::Celula(Console::formatarMoeda(f.total), Cor::VERDE)});
        d.desenhar();

        if (Console::lerInteiro("Confirmar devolucao com multa? [1=Sim / 0=Nao]") == 1) {
            FechamentoAtraso r = locacoes.registrarDevolucaoComMulta(loc->id);
            if (r.ok) {
                Console::sucesso("Atraso registrado. Multa: " + Console::formatarMoeda(r.multa) +
                                 " | Total: " + Console::formatarMoeda(r.total));
                // Salva imediatamente os dados financeiros (multa) em disco.
                Persistencia::salvarLocacoes(locacoes.getLocacoes());
            } else {
                Console::erro("Falha ao registrar o atraso.");
            }
        } else {
            Console::aviso("Operacao cancelada.");
        }
        Console::pausar();
    } catch (const std::exception& e) {
        Console::erro(std::string("Erro ao registrar atraso: ") + e.what());
        Console::pausar();
    }
}

// ─── HISTORICO / CONSULTAS ────────────────────────────────────────────────────

inline void telaHistoricoCliente(GerenciadorLocacoes& locacoes,
                                  GerenciadorClientes& clientes,
                                  GerenciadorFrota& frota) {
    Console::cabecalho("HISTORICO POR CLIENTE");

    if (clientes.getClientes().vazia()) {
        Console::aviso("Nenhum cliente cadastrado."); Console::pausar(); return;
    }
    // Dashboard de CLIENTES (para saber os IDs).
    gradeClientes(clientes).desenhar();
    std::cout << "\n";

    int idCliente; Cliente* cli = nullptr;
    while (true) {
        idCliente = Console::lerInteiro("ID do cliente (0 cancela)");
        if (idCliente == 0) return;
        cli = clientes.buscarPorId(idCliente);
        if (cli) break;
        Console::erro("Cliente nao encontrado. Tente novamente.");
    }

    std::cout << "\n  Cliente: " << Cor::CIANO << cli->nome << Cor::RESET
              << " | CPF: " << cli->cpf << "\n\n";

    auto hist = Consultas::historicoPorCliente(idCliente, locacoes);
    if (hist.vazio()) {
        Console::aviso("Nenhuma locacao encontrada para este cliente.");
        Console::pausar();
        return;
    }

    Tabela::Grade g = novaGradeLocacoes("HISTORICO - " + cli->nome);
    double totalGasto = 0;
    for (int i = 0; i < hist.getTamanho(); i++) {
        g.adicionar(celulasLocacao(hist[i], clientes, frota));
        if (hist[i].status == StatusLocacao::CONCLUIDA)
            totalGasto += hist[i].valorTotal;
    }
    g.desenhar();

    std::cout << "  Total locacoes : " << hist.getTamanho() << "\n";
    std::cout << "  Total gasto    : " << Cor::VERDE
              << Console::formatarMoeda(totalGasto) << Cor::RESET << "\n";

    Console::pausar();
}

inline void telaHistoricoVeiculo(GerenciadorLocacoes& locacoes,
                                  GerenciadorClientes& clientes,
                                  GerenciadorFrota& frota) {
    Console::cabecalho("HISTORICO POR VEICULO");

    if (frota.getFrota().vazia()) {
        Console::aviso("Nenhum veiculo cadastrado."); Console::pausar(); return;
    }
    // Dashboard da FROTA (para saber os IDs e placas).
    gradeFrota(frota).desenhar();
    std::cout << "\n";

    std::cout << "  [1] Buscar por ID\n  [2] Buscar por Placa\n  [0] Voltar\n";
    int op;
    while (true) {
        op = Console::lerInteiro("Opcao");
        if (op == 0) return;
        if (op == 1 || op == 2) break;
        Console::erro("Opcao invalida. Escolha 1 (ID), 2 (Placa) ou 0 (Voltar).");
    }

    Carro* car = nullptr;
    if (op == 1) {
        int id = Console::lerInteiro("ID do veiculo");
        car = frota.buscarPorId(id);
    } else {
        std::string placa = Console::lerTexto("Placa");
        car = frota.buscarPorPlaca(placa);
    }

    if (!car) { Console::erro("Veiculo nao encontrado."); Console::pausar(); return; }

    std::cout << "\n  Veiculo: " << Cor::CIANO
              << car->marca << " " << car->modelo << Cor::RESET
              << " | Placa: " << car->placa << "\n\n";

    auto hist = Consultas::historicoPorVeiculo(car->id, locacoes);
    if (hist.vazio()) {
        Console::aviso("Nenhuma locacao para este veiculo.");
        Console::pausar();
        return;
    }

    Tabela::Grade g = novaGradeLocacoes("HISTORICO - " + car->marca + " " + car->modelo +
                                        " (" + car->placa + ")");
    double totalReceita = 0;
    for (int i = 0; i < hist.getTamanho(); i++) {
        g.adicionar(celulasLocacao(hist[i], clientes, frota));
        if (hist[i].status == StatusLocacao::CONCLUIDA)
            totalReceita += hist[i].valorTotal;
    }
    g.desenhar();

    std::cout << "  Total locacoes : " << hist.getTamanho() << "\n";
    std::cout << "  Receita gerada : " << Cor::VERDE
              << Console::formatarMoeda(totalReceita) << Cor::RESET << "\n";

    Console::pausar();
}

inline void telaBuscaBinaria(GerenciadorLocacoes& locacoes,
                              GerenciadorClientes& clientes,
                              GerenciadorFrota& frota) {
    Console::cabecalho("BUSCA BINARIA - LOCACAO POR ID");
    Console::info("(Demonstra busca binaria em vetor ordenado por ID)");

    VetorDinamico<Locacao> vetor;
    locacoes.getLocacoes().paraCada([&](Locacao& l) { vetor.adicionar(l); });

    if (vetor.vazio()) {
        Console::aviso("Nenhuma locacao cadastrada.");
        Console::pausar();
        return;
    }

    // Dashboard com as locacoes existentes (IDs disponiveis para a busca).
    Tabela::Grade tabela = novaGradeLocacoes("LOCACOES (IDs disponiveis)");
    for (int i = 0; i < vetor.getTamanho(); i++)
        tabela.adicionar(celulasLocacao(vetor[i], clientes, frota));
    tabela.desenhar();
    std::cout << "\n";

    int idAlvo = Console::lerInteiro("ID da locacao a buscar");
    int idx    = Consultas::buscarLocacaoPorId(vetor, idAlvo);

    if (idx == -1) {
        Console::erro("Locacao #" + std::to_string(idAlvo) + " nao encontrada.");
    } else {
        Console::sucesso("Encontrado na posicao " + std::to_string(idx) +
                         " do vetor ordenado:");
        std::cout << "\n";
        Tabela::Grade g = novaGradeLocacoes("LOCACAO #" + std::to_string(idAlvo));
        g.adicionar(celulasLocacao(vetor[idx], clientes, frota));
        g.desenhar();
    }

    Console::pausar();
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────

inline void telaDashboard(GerenciadorFrota& frota,
                          GerenciadorClientes& clientes,
                          GerenciadorLocacoes& locacoes) {
    Console::cabecalho("DASHBOARD");

    int totalCarros = 0, disponiveis = 0, locados = 0, manutencao = 0;
    frota.getFrota().paraCada([&](Carro& c) {
        totalCarros++;
        if (c.status == StatusCarro::DISPONIVEL)  disponiveis++;
        if (c.status == StatusCarro::LOCADO)      locados++;
        if (c.status == StatusCarro::MANUTENCAO)  manutencao++;
    });

    auto emAtraso = Consultas::locacoesEmAtraso(locacoes);

    std::ostringstream fc;
    fc << std::fixed << std::setprecision(2) << frota.fatorCargaHash();

    // Painel FROTA (indicador/valor, sem numeracao de linha)
    Tabela::Grade gFrota("FROTA", false);
    gFrota.colunas({"INDICADOR", "VALOR"});
    gFrota.adicionar({Tabela::Celula("Total de veiculos"), Tabela::Celula(std::to_string(totalCarros))});
    gFrota.adicionar({Tabela::Celula("Disponiveis"),       Tabela::Celula(std::to_string(disponiveis), Cor::VERDE)});
    gFrota.adicionar({Tabela::Celula("Locados"),           Tabela::Celula(std::to_string(locados), Cor::AMARELO)});
    gFrota.adicionar({Tabela::Celula("Em manutencao"),     Tabela::Celula(std::to_string(manutencao), Cor::VERMELHO)});
    gFrota.adicionar({Tabela::Celula("Hash - fator carga"),Tabela::Celula(fc.str())});

    // Painel CLIENTES
    Tabela::Grade gCli("CLIENTES", false);
    gCli.colunas({"INDICADOR", "VALOR"});
    gCli.adicionar({Tabela::Celula("Total cadastrados"), Tabela::Celula(std::to_string(clientes.total()))});

    // Painel FINANCEIRO
    Tabela::Grade gFin("FINANCEIRO", false);
    gFin.colunas({"INDICADOR", "VALOR"});
    gFin.adicionar({Tabela::Celula("Locacoes ativas"), Tabela::Celula(std::to_string(locacoes.locacoesAtivas()))});
    gFin.adicionar({Tabela::Celula("Em atraso"),
                    Tabela::Celula(std::to_string(emAtraso.getTamanho()),
                                   emAtraso.vazio() ? Cor::VERDE : Cor::VERMELHO)});
    gFin.adicionar({Tabela::Celula("Receita prevista"),
                    Tabela::Celula(Console::formatarMoeda(locacoes.receitaPrevista()), Cor::AMARELO)});
    gFin.adicionar({Tabela::Celula("Receita realizada"),
                    Tabela::Celula(Console::formatarMoeda(locacoes.receitaTotal()), Cor::VERDE)});

    // Os tres paineis na mesma faixa horizontal.
    Tabela::desenharLadoALado({gFrota, gCli, gFin});

    Console::pausar();
}

// ─── FINANCEIRO ───────────────────────────────────────────────────────────────

inline void telaFinanceiro(GerenciadorLocacoes& locacoes,
                           GerenciadorClientes& clientes,
                           GerenciadorFrota& frota) {
    Console::cabecalho("FINANCEIRO");

    double diarias  = locacoes.receitaTotal();    // diarias de locacoes concluidas
    double multas   = locacoes.receitaMultas();
    double prevista = locacoes.receitaPrevista();
    auto   atraso   = Consultas::locacoesEmAtraso(locacoes);

    // Resumo financeiro.
    Tabela::Grade g("RESUMO FINANCEIRO", false);
    g.colunas({"INDICADOR", "VALOR"});
    g.larguraMinima(0, 26);
    g.adicionar({Tabela::Celula("Receita de diarias"),        Tabela::Celula(Console::formatarMoeda(diarias), Cor::VERDE)});
    g.adicionar({Tabela::Celula("Total de multas"),           Tabela::Celula(Console::formatarMoeda(multas), Cor::VERMELHO)});
    g.adicionar({Tabela::Celula("Receita total"),             Tabela::Celula(Console::formatarMoeda(diarias + multas), Cor::VERDE)});
    g.adicionar({Tabela::Celula("Receita prevista (ativas)"), Tabela::Celula(Console::formatarMoeda(prevista), Cor::AMARELO)});
    g.adicionar({Tabela::Celula("Locacoes ativas"),           Tabela::Celula(std::to_string(locacoes.locacoesAtivas()))});
    g.adicionar({Tabela::Celula("Locacoes em atraso"),        Tabela::Celula(std::to_string(atraso.getTamanho()), atraso.vazio() ? Cor::VERDE : Cor::VERMELHO)});
    g.desenhar();
    std::cout << "\n";

    // Multas aplicadas (locacoes concluidas com multa > 0).
    Tabela::Grade m("MULTAS APLICADAS");
    m.colunas({"LOC", "CLIENTE", "VEICULO", "MULTA"});
    m.larguraMinima(1, 24);
    locacoes.getLocacoes().paraCada([&](Locacao& l) {
        if (l.status == StatusLocacao::CONCLUIDA && l.multa > 0.0) {
            Cliente* cli = clientes.buscarPorId(l.idCliente);
            Carro*   car = frota.buscarPorId(l.idCarro);
            m.adicionar({
                Tabela::Celula(std::to_string(l.id)),
                Tabela::Celula(cli ? cli->nome : "?"),
                Tabela::Celula(car ? car->marca + " " + car->modelo : "?"),
                Tabela::Celula(Console::formatarMoeda(l.multa), Cor::VERMELHO)
            });
        }
    });
    if (!m.vazia()) m.desenhar();
    else Console::info("Nenhuma multa aplicada ate o momento.");

    Console::pausar();
}
