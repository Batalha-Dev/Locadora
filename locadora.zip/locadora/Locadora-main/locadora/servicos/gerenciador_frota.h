#pragma once
#include "../estruturas/lista_encadeada.h"
#include "../estruturas/lista_estatica.h"
#include "../estruturas/fila.h"
#include "../estruturas/hash_table.h"
#include "../estruturas/gerador_id.h"
#include "../modelos/carro.h"
#include "../modelos/categoria.h"
#include <cctype>

// Capacidade maxima de categorias: 6 padrao + espaco para novas cadastradas
// pelo usuario. O id da categoria e usado como indice de filaEspera[], por
// isso precisa ser < MAX_CATEGORIAS.
const int MAX_CATEGORIAS = 20;

class GerenciadorFrota {
private:
    ListaEncadeada<Carro>              frota;
    ListaEstatica<Categoria, MAX_CATEGORIAS> categorias;
    Fila<int>                          filaEspera[MAX_CATEGORIAS];

    // Hash tables para busca O(1) por placa e por id
    HashTable<std::string, int>        hashPorPlaca;   // placa → id
    HashTable<int, int>                hashPorId;      // id    → id (confirma existência)

    GeradorId geradorId;   // ids automaticos via pilha (usuario nunca digita)

    void carregarCategoriasPadrao() {
        categorias.inserir({0, "Economico",    "Carros compactos e populares",  80.0});
        categorias.inserir({1, "Intermediario","Sedas e hatches medios",       120.0});
        categorias.inserir({2, "SUV",          "Utilitarios esportivos",       180.0});
        categorias.inserir({3, "Luxo",         "Veiculos premium",             350.0});
        categorias.inserir({4, "Pickup",       "Caminhonetes",                 160.0});
        categorias.inserir({5, "Van",          "Vans e minivans",              200.0});
    }

public:
    GerenciadorFrota() {
        carregarCategoriasPadrao();
    }

    // ─── Categorias ──────────────────────────────────────────────
    const ListaEstatica<Categoria, MAX_CATEGORIAS>& getCategorias() const {
        return categorias;
    }
    Categoria* buscarCategoria(int id) {
        return categorias.buscar([id](const Categoria& c){ return c.id == id; });
    }

    // Busca categoria por nome (sem diferenciar maiusculas/minusculas).
    Categoria* buscarCategoriaPorNome(const std::string& nome) {
        return categorias.buscar([&](const Categoria& c){
            if (c.nome.size() != nome.size()) return false;
            for (size_t i = 0; i < nome.size(); ++i)
                if (std::tolower((unsigned char)c.nome[i]) !=
                    std::tolower((unsigned char)nome[i])) return false;
            return true;
        });
    }

    // Primeiro id livre em [0, MAX_CATEGORIAS). Suporta reuso de id apos remocao
    // e mantem o id sempre menor que MAX_CATEGORIAS (usado como indice da fila).
    int proximoIdCategoriaLivre() {
        for (int cand = 0; cand < MAX_CATEGORIAS; ++cand) {
            bool usado = false;
            for (int i = 0; i < categorias.getTamanho(); ++i)
                if (categorias[i].id == cand) { usado = true; break; }
            if (!usado) return cand;
        }
        return -1;
    }

    // Cadastra uma nova categoria com a diaria padrao definida pelo usuario.
    // Retorna nullptr se: lista cheia, diaria <= 0 ou nome ja existente.
    Categoria* adicionarCategoria(const std::string& nome,
                                  const std::string& descricao, double diaria) {
        if (categorias.cheia())            return nullptr;
        if (diaria <= 0.0)                 return nullptr;
        if (buscarCategoriaPorNome(nome))  return nullptr;
        int id = proximoIdCategoriaLivre();   // id < MAX_CATEGORIAS e sem colisao
        if (id < 0) return nullptr;
        categorias.inserir({id, nome, descricao, diaria});
        return buscarCategoria(id);
    }

    bool removerCategoria(int id) {
        for (int i = 0; i < categorias.getTamanho(); ++i)
            if (categorias[i].id == id) return categorias.remover(i);
        return false;
    }

    int contarVeiculosNaCategoria(int categoriaId) {
        int n = 0;
        frota.paraCada([&](Carro& c){ if (c.categoriaId == categoriaId) n++; });
        return n;
    }

    // Persistencia: zera as categorias e recoloca as vindas do arquivo.
    void limparCategorias() { categorias.limpar(); }
    void inserirCategoriaExistente(const Categoria& c) {
        if (!categorias.cheia()) categorias.inserir(c);
    }

    // ─── Frota ───────────────────────────────────────────────────
    Carro* cadastrar(const std::string& marca, const std::string& modelo,
                     const std::string& placa, int ano, int categoriaId) {
        if (!buscarCategoria(categoriaId)) return nullptr;
        // Placa duplicada não é permitida
        if (hashPorPlaca.buscar(placa)) return nullptr;
        // Regra de negócio (camada de dados): ano atual ou até 2 anos anteriores
        if (!anoVeiculoValido(ano)) return nullptr;

        Categoria* cat = buscarCategoria(categoriaId);
        double diaria = cat->diariaPadrao;

        int id = geradorId.obter();
        frota.inserirFim({id, marca, modelo, placa, ano, categoriaId, diaria});

        hashPorPlaca.inserir(placa, id);
        hashPorId.inserir(id, id);

        return frota.buscar([id](Carro& c){ return c.id == id; });
    }

    // Ajusta veículos com ano fora da regra (ano atual ou até 2 anteriores).
    // Usado após carregar do CSV: garante que a frota fique sempre dentro da lei,
    // independentemente do que estiver gravado no arquivo. Retorna quantos foram
    // corrigidos (a correção é persistida no próximo salvamento).
    int normalizarAnos() {
        int corrigidos = 0;
        int mn = anoVeiculoMinimo(), mx = anoVeiculoMaximo();
        frota.paraCada([&](Carro& c) {
            if (c.ano < mn)      { c.ano = mn; corrigidos++; }  // ajusta p/ ano legal mais antigo
            else if (c.ano > mx) { c.ano = mx; corrigidos++; }  // ajusta p/ ano atual
        });
        return corrigidos;
    }

    // Carrega carro já existente (vindo de arquivo) sem gerar novo id
    void inserirExistente(const Carro& c) {
        frota.inserirFim(c);
        hashPorPlaca.inserir(c.placa, c.id);
        hashPorId.inserir(c.id, c.id);
        geradorId.reservar(c.id);
    }

    bool remover(int id, bool reutilizarId = true) {
        Carro* c = buscarPorId(id);
        if (!c) return false;
        hashPorPlaca.remover(c->placa);
        hashPorId.remover(id);
        bool ok = frota.removerSe([id](const Carro& x){ return x.id == id; });
        if (ok && reutilizarId) geradorId.liberar(id);  // id volta para a pilha
        return ok;
    }

    // Busca O(1) via hash
    Carro* buscarPorId(int id) {
        int* encontrado = hashPorId.buscar(id);
        if (!encontrado) return nullptr;
        return frota.buscar([id](Carro& c){ return c.id == id; });
    }

    // Busca O(1) via hash
    Carro* buscarPorPlaca(const std::string& placa) {
        int* id = hashPorPlaca.buscar(placa);
        if (!id) return nullptr;
        return frota.buscar([id](Carro& c){ return c.id == *id; });
    }

    ListaEncadeada<Carro>& getFrota() { return frota; }

    bool marcarLocado(int id) {
        Carro* c = buscarPorId(id);
        if (!c || c->status != StatusCarro::DISPONIVEL) return false;
        c->status = StatusCarro::LOCADO;
        return true;
    }

    bool marcarDisponivel(int id) {
        Carro* c = buscarPorId(id);
        if (!c) return false;
        c->status = StatusCarro::DISPONIVEL;
        return true;
    }

    bool marcarManutencao(int id) {
        Carro* c = buscarPorId(id);
        if (!c || c->status == StatusCarro::LOCADO) return false;
        c->status = StatusCarro::MANUTENCAO;
        return true;
    }

    // ─── Fila de espera ──────────────────────────────────────────
    void entrarFilaEspera(int idCliente, int categoriaId) {
        if (categoriaId < 0 || categoriaId >= MAX_CATEGORIAS) return;
        filaEspera[categoriaId].enfileirar(idCliente);
    }

    int proximoDaFila(int categoriaId) {
        if (categoriaId < 0 || categoriaId >= MAX_CATEGORIAS) return -1;
        if (filaEspera[categoriaId].vazia()) return -1;
        return filaEspera[categoriaId].desenfileirar();
    }

    int tamanhoFila(int categoriaId) const {
        if (categoriaId < 0 || categoriaId >= MAX_CATEGORIAS) return 0;
        return filaEspera[categoriaId].getTamanho();
    }

    int contarDisponiveis(int categoriaId) {
        int count = 0;
        frota.paraCada([&](Carro& c) {
            if (c.categoriaId == categoriaId && c.status == StatusCarro::DISPONIVEL)
                count++;
        });
        return count;
    }

    float fatorCargaHash() const { return hashPorPlaca.fatorCarga(); }
};
