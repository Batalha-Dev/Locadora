#pragma once
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include "../modelos/locacao.h"
#include "../modelos/cliente.h"
#include "../modelos/carro.h"

// ─────────────────────────────────────────────────────────────────────────────
//  Geracao de contrato de locacao em PDF (sem bibliotecas externas).
//  Escreve um arquivo PDF 1.4 valido com fontes padrao (Helvetica) e o texto
//  juridico do contrato. Cada locacao gera juridico/contrato_<id>.pdf.
// ─────────────────────────────────────────────────────────────────────────────
namespace Contrato {

// Dados (fixos) da LOCADORA — constam em TODOS os contratos.
const std::string EMPRESA      = "Locadora Claudio Ltda.";
const std::string PROPRIETARIO = "Claudio Anthropico";
const std::string CNPJ         = "12.345.678/0001-90";   // CNPJ ficticio

// ── Helpers de formatacao ────────────────────────────────────────────────────
inline std::string reais(double v) {
    char b[40]; std::snprintf(b, sizeof(b), "%.2f", v);
    std::string s(b);
    for (char& c : s) if (c == '.') c = ',';   // formato brasileiro
    return "R$ " + s;
}

inline std::string dataBR(time_t t) {
    if (t == 0) return "--/--/----";
    char b[16]; struct tm* i = std::localtime(&t);
    std::strftime(b, sizeof(b), "%d/%m/%Y", i);
    return std::string(b);
}

inline std::string num(double v) {
    char b[32]; std::snprintf(b, sizeof(b), "%.2f", v); return std::string(b);
}

// Converte UTF-8 -> Latin-1/WinAnsi (1 byte) para as fontes padrao do PDF.
// Acentos do portugues sao mapeados direto; fora do Latin-1 vira '?'.
inline std::string utf8ParaLatin1(const std::string& s) {
    std::string r;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = s[i];
        unsigned int cp; int len;
        if (c < 0x80)             { cp = c;        len = 1; }
        else if ((c >> 5) == 0x6) { cp = c & 0x1F; len = 2; }
        else if ((c >> 4) == 0xE) { cp = c & 0x0F; len = 3; }
        else if ((c >> 3) == 0x1E){ cp = c & 0x07; len = 4; }
        else { ++i; r += '?'; continue; }
        for (int k = 1; k < len && i + (size_t)k < s.size(); ++k)
            cp = (cp << 6) | (s[i + k] & 0x3F);
        i += len;
        r += (cp < 0x100) ? (char)(unsigned char)cp : '?';
    }
    return r;
}

inline std::string escaparPDF(const std::string& s) {
    std::string r;
    for (char c : s) { if (c == '(' || c == ')' || c == '\\') r += '\\'; r += c; }
    return r;
}

// ── Escritor de PDF simples (texto em multiplas paginas A4) ───────────────────
class EscritorPDF {
    const double W = 595.0, H = 842.0;          // A4 em pontos
    const double mEsq = 56, mDir = 56, mTopo = 64, mBaixo = 64;
    double y;
    std::vector<std::string> paginas;
    std::string buf;

    void abrirPagina() { buf.clear(); y = H - mTopo; }
    void fecharPagina() { paginas.push_back(buf); }
    double largura(const std::string& t, double tam) { return t.size() * tam * 0.5; }

    void desenhar(const std::string& txt, double x, double yy, double tam, bool neg) {
        buf += "BT\n";
        buf += (neg ? "/F2 " : "/F1 ") + num(tam) + " Tf\n";
        buf += num(x) + " " + num(yy) + " Td\n";
        buf += "(" + txt + ") Tj\nET\n";
    }
    void quebraSePreciso(double tam) {
        if (y - tam * 1.45 < mBaixo) { fecharPagina(); abrirPagina(); }
    }

public:
    EscritorPDF() { abrirPagina(); }

    void linha(const std::string& texto, double tam = 11, bool neg = false,
               bool centro = false, double recuo = 0) {
        quebraSePreciso(tam);
        std::string l1 = utf8ParaLatin1(texto);
        double x = mEsq + recuo;
        if (centro) x = (W - largura(l1, tam)) / 2.0;
        y -= tam * 1.45;
        desenhar(escaparPDF(l1), x, y, tam, neg);
    }

    void vazia(double tam = 11) { quebraSePreciso(tam); y -= tam; }

    // Paragrafo com quebra automatica de linha (justificado a esquerda).
    void paragrafo(const std::string& texto, double tam = 11, double recuo = 0) {
        double maxW = W - mEsq - mDir - recuo;
        std::istringstream iss(utf8ParaLatin1(texto));
        std::string palavra, atual;
        while (iss >> palavra) {
            std::string tent = atual.empty() ? palavra : atual + " " + palavra;
            if (largura(tent, tam) > maxW && !atual.empty()) {
                // imprime 'atual' (ja em latin1) sem reconverter
                quebraSePreciso(tam);
                y -= tam * 1.45;
                desenhar(escaparPDF(atual), mEsq + recuo, y, tam, false);
                atual = palavra;
            } else atual = tent;
        }
        if (!atual.empty()) {
            quebraSePreciso(tam);
            y -= tam * 1.45;
            desenhar(escaparPDF(atual), mEsq + recuo, y, tam, false);
        }
    }

    std::vector<std::string> finalizar() { fecharPagina(); return paginas; }
};

// ── Serializa as paginas (content streams) num arquivo PDF valido ─────────────
inline std::string montarPDF(const std::vector<std::string>& streams) {
    int nPag = (int)streams.size();
    int total = 4 + 2 * nPag;
    std::vector<std::string> obj(total + 1);

    obj[1] = "<< /Type /Catalog /Pages 2 0 R >>";
    std::string kids;
    for (int i = 0; i < nPag; ++i) kids += std::to_string(5 + 2 * i) + " 0 R ";
    obj[2] = "<< /Type /Pages /Kids [ " + kids + "] /Count " + std::to_string(nPag) + " >>";
    obj[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
    obj[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
    for (int i = 0; i < nPag; ++i) {
        int pg = 5 + 2 * i, ct = 6 + 2 * i;
        obj[pg] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
                  "/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> "
                  "/Contents " + std::to_string(ct) + " 0 R >>";
        const std::string& s = streams[i];
        obj[ct] = "<< /Length " + std::to_string(s.size()) + " >>\nstream\n" + s + "\nendstream";
    }

    std::string out = "%PDF-1.4\n";
    std::vector<size_t> off(total + 1, 0);
    for (int i = 1; i <= total; ++i) {
        off[i] = out.size();
        out += std::to_string(i) + " 0 obj\n" + obj[i] + "\nendobj\n";
    }
    size_t xref = out.size();
    out += "xref\n0 " + std::to_string(total + 1) + "\n";
    out += "0000000000 65535 f \n";
    for (int i = 1; i <= total; ++i) {
        char b[32]; std::snprintf(b, sizeof(b), "%010zu 00000 n \n", off[i]);
        out += b;
    }
    out += "trailer\n<< /Size " + std::to_string(total + 1) + " /Root 1 0 R >>\n";
    out += "startxref\n" + std::to_string(xref) + "\n%%EOF\n";
    return out;
}

// ── Gera o contrato da locacao e salva em juridico/contrato_<id>.pdf ──────────
// Retorna o caminho do arquivo, ou string vazia em caso de falha.
inline std::string gerarContratoLocacao(const Locacao& loc, const Cliente& cli,
                                        const Carro& car, const std::string& categoria,
                                        int dias) {
#ifdef _WIN32
    std::system("if not exist juridico mkdir juridico");
#else
    std::system("mkdir -p juridico");
#endif

    EscritorPDF pdf;
    pdf.linha("CONTRATO DE LOCACAO DE VEICULO", 16, true, true);
    pdf.linha("Contrato n. " + std::to_string(loc.id), 10, false, true);
    pdf.vazia();

    pdf.paragrafo("Pelo presente instrumento particular, de um lado " + EMPRESA +
        ", pessoa juridica de direito privado, inscrita no CNPJ sob o n. " + CNPJ +
        ", neste ato representada por seu proprietario, Sr. " + PROPRIETARIO +
        ", doravante denominada LOCADORA, e de outro lado o(a) LOCATARIO(A) abaixo "
        "qualificado(a), tem entre si, justo e contratado, o presente Contrato de Locacao "
        "de Veiculo, que se regera pelas clausulas e condicoes seguintes.");
    pdf.vazia();

    pdf.linha("DA LOCADORA", 12, true);
    pdf.linha("Razao social: " + EMPRESA);
    pdf.linha("Proprietario: " + PROPRIETARIO);
    pdf.linha("CNPJ: " + CNPJ);
    pdf.vazia();

    pdf.linha("DO(A) LOCATARIO(A)", 12, true);
    pdf.linha("Nome: " + cli.nome);
    pdf.linha("CPF: " + cli.cpf + "     Telefone: " + cli.telefone);
    pdf.linha("E-mail: " + cli.email);
    pdf.vazia();

    pdf.linha("CLAUSULA 1a - DO OBJETO", 12, true);
    pdf.paragrafo("Constitui objeto deste contrato a locacao, pela LOCADORA ao(a) LOCATARIO(A), "
        "do veiculo automotor a seguir descrito:");
    pdf.linha("Veiculo: " + car.marca + " " + car.modelo);
    pdf.linha("Placa: " + car.placa + "     Ano: " + std::to_string(car.ano) +
              "     Categoria: " + categoria);
    pdf.vazia();

    pdf.linha("CLAUSULA 2a - DO PRAZO", 12, true);
    pdf.paragrafo("A presente locacao tera o prazo de " + std::to_string(dias) +
        " diaria(s), com retirada do veiculo em " + dataBR(loc.dataInicio) +
        " e devolucao prevista para " + dataBR(loc.dataFimPrevista) +
        ", podendo ser prorrogada mediante novo ajuste entre as partes.");
    pdf.vazia();

    pdf.linha("CLAUSULA 3a - DO VALOR E DO PAGAMENTO", 12, true);
    pdf.paragrafo("O valor da diaria e de " + reais(car.diaria) + ", totalizando " +
        reais(loc.valorTotal) + " pelo periodo ora contratado, valor que o(a) LOCATARIO(A) "
        "se obriga a pagar a LOCADORA na forma e nas datas acordadas.");
    pdf.vazia();

    pdf.linha("CLAUSULA 4a - DAS OBRIGACOES DO(A) LOCATARIO(A)", 12, true);
    pdf.paragrafo("O(a) LOCATARIO(A) obriga-se a: (i) utilizar o veiculo com diligencia e "
        "observancia a legislacao de transito; (ii) responder por multas, infracoes e despesas "
        "decorrentes do uso durante o periodo da locacao; (iii) restituir o veiculo no prazo "
        "ajustado e nas mesmas condicoes em que o recebeu, ressalvado o desgaste natural; "
        "(iv) comunicar de imediato a LOCADORA qualquer sinistro, avaria, furto ou roubo.");
    pdf.vazia();

    pdf.linha("CLAUSULA 5a - DA DEVOLUCAO E DA MULTA", 12, true);
    pdf.paragrafo("A devolucao do veiculo apos a data prevista implicara a cobranca das diarias "
        "adicionais correspondentes, acrescidas da multa contratual, sem prejuizo das demais "
        "penalidades previstas em lei e neste instrumento.");
    pdf.vazia();

    pdf.linha("CLAUSULA 6a - DO FORO", 12, true);
    pdf.paragrafo("As partes elegem o foro da comarca do domicilio da LOCADORA para dirimir "
        "quaisquer duvidas ou litigios oriundos do presente contrato, com renuncia a qualquer "
        "outro, por mais privilegiado que seja.");
    pdf.vazia();

    pdf.paragrafo("E, por estarem assim justas e contratadas, as partes assinam o presente "
        "instrumento em duas vias de igual teor e forma.");
    pdf.vazia(); pdf.vazia();
    pdf.linha("Local e data: __________________________________, " + dataBR(loc.dataInicio));
    pdf.vazia(); pdf.vazia();
    pdf.linha("______________________________________");
    pdf.linha("LOCADORA - " + EMPRESA);
    pdf.linha(PROPRIETARIO + " - Proprietario   |   CNPJ: " + CNPJ);
    pdf.vazia();
    pdf.linha("______________________________________");
    pdf.linha("LOCATARIO(A) - " + cli.nome);

    std::string conteudo = montarPDF(pdf.finalizar());
    std::string caminho = "juridico/contrato_" + std::to_string(loc.id) + ".pdf";
    std::ofstream f(caminho, std::ios::binary);
    if (!f.is_open()) return "";
    f.write(conteudo.data(), (std::streamsize)conteudo.size());
    return f.good() ? caminho : "";
}

// Proximo numero sequencial de aditivo para a locacao (1, 2, 3, ...),
// baseado nos arquivos ja existentes em juridico/.
inline int proximoNumeroAditivo(int idLocacao) {
    int n = 1;
    while (true) {
        std::string p = "juridico/aditivo_" + std::to_string(idLocacao) +
                        "_" + std::to_string(n) + ".pdf";
        std::ifstream f(p);
        if (!f.good()) return n;
        ++n;
    }
}

// Gera um TERMO ADITIVO de renovacao (documento separado, preservando o
// contrato original). Salva em juridico/aditivo_<idLocacao>_<n>.pdf.
inline std::string gerarTermoAditivo(const Locacao& loc, const Cliente& cli,
                                     const Carro& car, const std::string& categoria,
                                     int diasAdicionais) {
#ifdef _WIN32
    std::system("if not exist juridico mkdir juridico");
#else
    std::system("mkdir -p juridico");
#endif
    int n = proximoNumeroAditivo(loc.id);
    double acrescimo = diasAdicionais * car.diaria;

    EscritorPDF pdf;
    pdf.linha("TERMO ADITIVO DE RENOVACAO", 16, true, true);
    pdf.linha("Aditivo n. " + std::to_string(n) + " ao Contrato de Locacao n. " +
              std::to_string(loc.id), 10, false, true);
    pdf.vazia();

    pdf.paragrafo("Pelo presente Termo Aditivo, de um lado " + EMPRESA +
        ", inscrita no CNPJ sob o n. " + CNPJ + ", neste ato representada por seu "
        "proprietario, Sr. " + PROPRIETARIO + ", doravante denominada LOCADORA, e de outro "
        "lado o(a) LOCATARIO(A) " + cli.nome + ", inscrito(a) no CPF sob o n. " + cli.cpf +
        ", resolvem, de comum acordo, RENOVAR a locacao objeto do Contrato n. " +
        std::to_string(loc.id) + ", nos termos das clausulas seguintes.");
    pdf.vazia();

    pdf.linha("DA LOCADORA", 12, true);
    pdf.linha("Razao social: " + EMPRESA);
    pdf.linha("Proprietario: " + PROPRIETARIO);
    pdf.linha("CNPJ: " + CNPJ);
    pdf.vazia();

    pdf.linha("DO(A) LOCATARIO(A)", 12, true);
    pdf.linha("Nome: " + cli.nome);
    pdf.linha("CPF: " + cli.cpf + "     Telefone: " + cli.telefone);
    pdf.vazia();

    pdf.linha("DO VEICULO", 12, true);
    pdf.linha("Veiculo: " + car.marca + " " + car.modelo);
    pdf.linha("Placa: " + car.placa + "     Ano: " + std::to_string(car.ano) +
              "     Categoria: " + categoria);
    pdf.vazia();

    pdf.linha("CLAUSULA 1a - DA RENOVACAO DO PRAZO", 12, true);
    pdf.paragrafo("Fica o prazo da locacao acrescido de " + std::to_string(diasAdicionais) +
        " diaria(s), passando a devolucao prevista a ocorrer em " +
        dataBR(loc.dataFimPrevista) + ".");
    pdf.vazia();

    pdf.linha("CLAUSULA 2a - DO VALOR ADITADO", 12, true);
    pdf.paragrafo("Em razao da renovacao, fica acrescido ao contrato o valor de " +
        reais(acrescimo) + " (referente a " + std::to_string(diasAdicionais) +
        " diaria(s) de " + reais(car.diaria) + "), passando o valor total do contrato "
        "a ser de " + reais(loc.valorTotal) + ".");
    pdf.vazia();

    pdf.linha("CLAUSULA 3a - DA RATIFICACAO", 12, true);
    pdf.paragrafo("Permanecem inalteradas e ora ratificadas todas as demais clausulas e "
        "condicoes do Contrato de Locacao n. " + std::to_string(loc.id) +
        " que nao conflitem com o presente Termo Aditivo.");
    pdf.vazia(); pdf.vazia();

    pdf.linha("Local e data: __________________________________, " + dataBR(std::time(nullptr)));
    pdf.vazia(); pdf.vazia();
    pdf.linha("______________________________________");
    pdf.linha("LOCADORA - " + EMPRESA);
    pdf.linha(PROPRIETARIO + " - Proprietario   |   CNPJ: " + CNPJ);
    pdf.vazia();
    pdf.linha("______________________________________");
    pdf.linha("LOCATARIO(A) - " + cli.nome);

    std::string conteudo = montarPDF(pdf.finalizar());
    std::string caminho = "juridico/aditivo_" + std::to_string(loc.id) +
                          "_" + std::to_string(n) + ".pdf";
    std::ofstream f(caminho, std::ios::binary);
    if (!f.is_open()) return "";
    f.write(conteudo.data(), (std::streamsize)conteudo.size());
    return f.good() ? caminho : "";
}

} // namespace Contrato
